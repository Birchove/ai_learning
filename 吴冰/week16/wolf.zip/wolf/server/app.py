from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from contextlib import asynccontextmanager

from server.controller import GameController
from server.models import (
    GameCreateResponse,
    GameStateResponse,
    PlayerOut,
    GameLogResponse,
    LogEntryOut,
    GameSummaryResponse,
    AgentSummaryOut,
    GameListResponse,
    GameDetailResponse,
    PlayerDetailOut,
    TimelineEntryOut,
)

controller = GameController()


@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"Server started. API docs at http://localhost:8000/docs")
    yield


app = FastAPI(
    title="AI Werewolf — 狼人杀对战 API",
    description="""
    AI 狼人杀多智能体对战系统。

    ## 快速开始
    1. `POST /api/games` — 创建一局新游戏
    2. `GET /api/games/{id}` — 查看游戏状态
    3. `POST /api/games/{id}/run` — 启动 AI 自动对战
    4. `GET /api/games/{id}/log` — 查看完整对局日志
    5. `GET /api/games/{id}/summaries` — 查看 Agent 赛后总结

    也可用 `GET /api/games` 列出所有游戏。
    """,
    version="1.0.0",
    lifespan=lifespan,
)

# CORS — 允许前端跨域访问
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 挂载前端静态页面
import os
frontend_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend", "index.html"))


@app.get("/", include_in_schema=False)
def serve_frontend():
    return FileResponse(frontend_path)


# ============================================================
#  Game CRUD
# ============================================================

@app.get("/api/games", response_model=GameListResponse, tags=["Game"])
def list_games():
    """列出所有进行中的游戏"""
    ids = controller.list_ids()
    return GameListResponse(games=ids, count=len(ids))


@app.post("/api/games", response_model=GameCreateResponse, status_code=201, tags=["Game"])
def create_game():
    """创建一局新的狼人杀游戏（7人局：2狼、预言家、女巫、猎人、2平民）"""
    game = controller.create()
    return GameCreateResponse(
        game_id=game.game_id,
        message=f"游戏 {game.game_id} 已创建，共 {len(game.state.players)} 名玩家",
    )


@app.get("/api/games/{game_id}", response_model=GameStateResponse, tags=["Game"])
def get_game_state(game_id: str):
    """查看当前游戏状态"""
    game = controller.get(game_id)
    if not game:
        raise HTTPException(status_code=404, detail="游戏不存在")

    s = game.state
    return GameStateResponse(
        game_id=game_id,
        round_number=s.round_number,
        phase=s.phase.value if not s.game_over else "finished",
        finished=s.game_over,
        winner=s.winner.value if s.winner else None,
        alive_count=len(s.alive_players),
        dead_count=len(s.players) - len(s.alive_players),
        players=[
            PlayerOut(
                player_id=p.player_id,
                name=p.name,
                role=p.role.value if not p.is_alive and p.revealed_role else "unknown" if p.is_alive else p.role.value,
                is_alive=p.is_alive,
                revealed_role=p.revealed_role.value if p.revealed_role else None,
                is_silver_water=p.is_silver_water,
            )
            for p in s.players
        ],
    )


# ============================================================
#  Game Actions
# ============================================================

@app.post("/api/games/{game_id}/run", tags=["Game Actions"])
def run_game(game_id: str):
    """运行 AI 自动对战（后台异步运行，前端可轮询进度）"""
    game = controller.get(game_id)
    if not game:
        raise HTTPException(status_code=404, detail="游戏不存在")
    if game.finished:
        raise HTTPException(status_code=400, detail="游戏已经结束")
    if game.running:
        raise HTTPException(status_code=400, detail="游戏正在运行中")

    game.run_auto()
    s = game.state
    return GameStateResponse(
        game_id=game_id,
        round_number=s.round_number,
        phase="finished",
        finished=True,
        winner=s.winner.value if s.winner else None,
        alive_count=len(s.alive_players),
        dead_count=len(s.players) - len(s.alive_players),
        players=[
            PlayerOut(
                player_id=p.player_id,
                name=p.name,
                role=p.role.value,
                is_alive=p.is_alive,
                revealed_role=p.revealed_role.value if p.revealed_role else None,
                is_silver_water=p.is_silver_water,
            )
            for p in s.players
        ],
    )


# ============================================================
#  Logs & Summaries
# ============================================================

@app.get("/api/games/{game_id}/log", response_model=GameLogResponse, tags=["Results"])
def get_game_log(game_id: str):
    """获取游戏完整结构化日志"""
    game = controller.get(game_id)
    if not game:
        raise HTTPException(status_code=404, detail="游戏不存在")

    return GameLogResponse(
        game_id=game_id,
        entries=[
            LogEntryOut(round=e.round, phase=e.phase, content=e.content)
            for e in game.logger.entries
        ],
    )


@app.get("/api/games/{game_id}/summaries", response_model=GameSummaryResponse, tags=["Results"])
def get_game_summaries(game_id: str):
    """获取所有 Agent 的赛后总结"""
    game = controller.get(game_id)
    if not game:
        raise HTTPException(status_code=404, detail="游戏不存在")
    if not game.finished:
        raise HTTPException(status_code=400, detail="游戏尚未结束，请先运行")

    summaries = game.get_summaries()
    s = game.state
    return GameSummaryResponse(
        game_id=game_id,
        winner=s.winner.value if s.winner else None,
        summaries=[
            AgentSummaryOut(
                player_id=s["player_id"],
                name=s["name"],
                role=s["role"],
                is_alive=s["is_alive"],
                summary=s["summary"],
            )
            for s in summaries
        ],
        player_count=len(s.players),
        total_rounds=s.round_number,
    )


@app.get("/api/games/{game_id}/detail", response_model=GameDetailResponse, tags=["Results"])
def get_game_detail(game_id: str):
    """获取游戏详细过程，包含每个玩家的完整时间线和推理过程"""
    game = controller.get(game_id)
    if not game:
        raise HTTPException(status_code=404, detail="游戏不存在")
    if not game.finished:
        raise HTTPException(status_code=400, detail="游戏尚未结束")

    players = game.get_player_details()
    s = game.state
    return GameDetailResponse(
        game_id=game_id,
        winner=s.winner.value if s.winner else None,
        total_rounds=s.round_number,
        finished=True,
        players=[
            PlayerDetailOut(
                player_id=p["player_id"],
                name=p["name"],
                role=p["role"],
                is_alive=p["is_alive"],
                death_cause=p.get("death_cause"),
                death_round=p.get("death_round"),
                is_silver_water=p["is_silver_water"],
                timeline=[
                    TimelineEntryOut(
                        round=t["round"],
                        phase=t["phase"],
                        action=t.get("action"),
                        reasoning=t.get("reasoning", ""),
                    )
                    for t in p["timeline"]
                ],
            )
            for p in players
        ],
    )
