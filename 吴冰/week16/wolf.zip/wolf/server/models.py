from pydantic import BaseModel
from typing import Optional


class GameCreateResponse(BaseModel):
    game_id: str
    message: str


class PlayerOut(BaseModel):
    player_id: int
    name: str
    role: str
    is_alive: bool
    revealed_role: Optional[str] = None
    is_silver_water: bool = False


class GameStateResponse(BaseModel):
    game_id: str
    round_number: int
    phase: str
    finished: bool
    winner: Optional[str] = None
    alive_count: int
    dead_count: int
    players: list[PlayerOut]


class SpeechOut(BaseModel):
    player_id: int
    content: str
    round_number: int


class VoteOut(BaseModel):
    voter: int
    target: int


class LogEntryOut(BaseModel):
    round: int
    phase: str
    content: str


class GameLogResponse(BaseModel):
    game_id: str
    entries: list[LogEntryOut]


class AgentSummaryOut(BaseModel):
    player_id: int
    name: str
    role: str
    is_alive: bool
    summary: str


class GameSummaryResponse(BaseModel):
    game_id: str
    winner: Optional[str]
    summaries: list[AgentSummaryOut]
    player_count: int
    total_rounds: int


class GameListResponse(BaseModel):
    games: list[str]
    count: int


# ============================================================
#  Game Detail (with agent reasoning)
# ============================================================

class TimelineEntryOut(BaseModel):
    round: int
    phase: str
    action: Optional[dict] = None
    reasoning: str = ""


class PlayerDetailOut(BaseModel):
    player_id: int
    name: str
    role: str
    is_alive: bool
    death_cause: Optional[str] = None
    death_round: Optional[int] = None
    is_silver_water: bool = False
    timeline: list[TimelineEntryOut]


class GameDetailResponse(BaseModel):
    game_id: str
    winner: Optional[str] = None
    total_rounds: int
    finished: bool
    players: list[PlayerDetailOut]


class ErrorResponse(BaseModel):
    detail: str
