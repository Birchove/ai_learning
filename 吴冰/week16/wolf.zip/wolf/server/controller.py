import uuid
import threading
from typing import Optional

from game.state import GameState
from game.logger import GameLogger
from game.engine import GameEngine
from game.enums import Role

from agents.werewolf import WerewolfAgent
from agents.seer import SeerAgent
from agents.witch import WitchAgent
from agents.hunter import HunterAgent
from agents.villager import VillagerAgent

AGENT_MAP = {
    Role.WEREWOLF: WerewolfAgent,
    Role.SEER: SeerAgent,
    Role.WITCH: WitchAgent,
    Role.HUNTER: HunterAgent,
    Role.VILLAGER: VillagerAgent,
}


class ManagedGame:
    def __init__(self):
        self.game_id: str = uuid.uuid4().hex[:8]
        self.state: GameState = GameState()
        self.logger: GameLogger = GameLogger()
        self.engine: GameEngine = GameEngine(self.state, self.logger)
        self.finished: bool = False
        self.running: bool = False

    def setup(self) -> None:
        self.engine.setup_players()
        for player in self.state.players:
            agent_cls = AGENT_MAP[player.role]
            agent = agent_cls(player.player_id)
            self.engine.register_agent(agent)

    def run_auto(self) -> GameState:
        self.running = True
        try:
            self.engine.run_game()
        finally:
            self.finished = True
            self.running = False
        return self.state

    def run_async(self) -> None:
        """在后台线程中异步运行对局"""
        t = threading.Thread(target=self.run_auto, daemon=True)
        t.start()

    def get_summaries(self) -> list[dict]:
        summaries = []
        for player in self.state.players:
            agent = self.engine.agent_map[player.player_id]
            summaries.append({
                "player_id": player.player_id,
                "name": player.name,
                "role": player.role.value,
                "is_alive": player.is_alive,
                "summary": agent.summarize(),
            })
        return summaries

    def get_player_details(self) -> list[dict]:
        """返回每个玩家的完整时间线（含推理过程、死亡信息）"""
        result = []
        s = self.state
        for player in s.players:
            agent = self.engine.agent_map[player.player_id]
            timeline = agent.get_timeline()

            # 如果玩家出局，追加死亡事件
            enriched = list(timeline)
            if not player.is_alive and player.death_cause:
                enriched.append({
                    "round": player.death_round,
                    "phase": "death",
                    "action": {"event": "death", "cause": player.death_cause},
                    "reasoning": "",
                })

            result.append({
                "player_id": player.player_id,
                "name": player.name,
                "role": player.role.value,
                "is_alive": player.is_alive,
                "death_cause": player.death_cause if not player.is_alive else None,
                "death_round": player.death_round if not player.is_alive else None,
                "is_silver_water": player.is_silver_water,
                "timeline": enriched,
            })
        return result


class GameController:
    def __init__(self):
        self._games: dict[str, ManagedGame] = {}

    def create(self) -> ManagedGame:
        game = ManagedGame()
        game.setup()
        self._games[game.game_id] = game
        return game

    def get(self, game_id: str) -> Optional[ManagedGame]:
        return self._games.get(game_id)

    def list_ids(self) -> list[str]:
        return list(self._games.keys())
