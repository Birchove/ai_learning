"""狼人杀 AI 对战系统 — 主入口"""

import os
import sys

# Windows 终端 UTF-8 支持
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from game.enums import Role
from game.state import GameState
from game.logger import GameLogger
from game.engine import GameEngine

from agents.werewolf import WerewolfAgent
from agents.seer import SeerAgent
from agents.witch import WitchAgent
from agents.hunter import HunterAgent
from agents.villager import VillagerAgent


def create_agent(player_id: int, role: Role):
    """根据角色创建对应的 Agent"""
    mapping = {
        Role.WEREWOLF: WerewolfAgent,
        Role.SEER: SeerAgent,
        Role.WITCH: WitchAgent,
        Role.HUNTER: HunterAgent,
        Role.VILLAGER: VillagerAgent,
    }
    return mapping[role](player_id)


def main():
    # 初始化
    state = GameState()
    logger = GameLogger()
    engine = GameEngine(state, logger)

    # 设置玩家
    engine.setup_players()

    # 为每个玩家创建 Agent 并注册
    for player in state.players:
        agent = create_agent(player.player_id, player.role)
        engine.register_agent(agent)

    # 运行游戏
    state = engine.run_game()

    # ================================================================
    #  赛后总结：每个 Agent 回顾自己的表现
    # ================================================================
    print("\n" + "=" * 60)
    print("                 Agent 赛后总结")
    print("=" * 60)
    for player in state.players:
        agent = engine.agent_map[player.player_id]
        summary = agent.summarize()
        status = "存活" if player.is_alive else "出局"
        print(f"\n【{player.name}】({status})")
        print(f"  {summary}")

    # 打印完整日志
    print("\n" + "=" * 60)
    print("                 完 整 对 局 日 志")
    print("=" * 60)
    logger.print_summary()


if __name__ == "__main__":
    main()
