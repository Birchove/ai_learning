import random
from .base import BaseAgent


class WitchAgent(BaseAgent):
    """女巫 Agent — 有解药和毒药，掌握夜间死亡信息"""

    SAVE_REASONS_R1 = [
        "首夜狼人杀了{wolf_target}号，我用解药救他。首夜救人很重要，万一死的是关键神职就亏了。{wolf_target}号成为我的银水。",
        "首夜{wolf_target}号被刀，必须救。首夜不救人的话死了预言家就直接崩盘了。",
    ]
    SAVE_REASONS_LATE = [
        "狼人杀了{wolf_target}号，我选择救他。多救一个人好人就多一份力量，后期人数优势很重要。",
        "狼人杀了{wolf_target}号，先救下来看看他后续发言，银水也有可能帮我们带队。",
    ]
    SKIP_SAVE_REASONS = [
        "狼人杀了{wolf_target}号，我选择不救。解药要留到关键时刻，不能随便浪费。",
        "狼人杀了{wolf_target}号，先不救了，我觉得他可能不是核心神职。留着解药关键轮次再用。",
    ]
    POISON_REASONS = [
        "我怀疑{target}号是狼人，用毒药把他毒死。女巫的毒药就是用来除掉确定的狼人。",
        "我判断{target}号大概率是狼，果断毒掉他，帮好人排坑。",
        "{target}号的发言前后矛盾，身份做不成好人，毒了不亏。",
    ]
    SPEECH_TEMPLATES = [
        "我是好人，目前听下来觉得有一些玩家发言不太做好，再听听大家的看法。",
        "这一轮信息还不够多，我想先听听预言家的验人结果再做判断。",
        "我暂时不会站边，等更多信息出来再说。大家理性分析。",
        "我注意到{wlist}号玩家发言有一点问题，但还需要观察。",
    ]

    def __init__(self, player_id: int):
        super().__init__(player_id)
        self._suspicious: set[int] = set()
        self._saved: set[int] = set()

    def on_night(self, observable_state: dict) -> dict:
        wolf_target = observable_state.get("wolf_kill_target")
        antidote = observable_state.get("antidote_remaining", False)
        poison = observable_state.get("poison_remaining", False)

        decision = {}
        reasoning = ""

        if wolf_target and antidote:
            if observable_state["round"] == 1:
                tmpl = random.choice(self.SAVE_REASONS_R1)
                decision = {"action": "save"}
                self._saved.add(wolf_target)
                reasoning = tmpl.format(wolf_target=wolf_target)
            else:
                if random.random() < 0.5:
                    tmpl = random.choice(self.SAVE_REASONS_LATE)
                    decision = {"action": "save"}
                    self._saved.add(wolf_target)
                    reasoning = tmpl.format(wolf_target=wolf_target)
                else:
                    tmpl = random.choice(self.SKIP_SAVE_REASONS)
                    decision = {"action": "skip"}
                    reasoning = tmpl.format(wolf_target=wolf_target)

        elif poison and self._suspicious:
            alive = observable_state["alive_players"]
            targets = self._suspicious & set(alive)
            if targets:
                target = list(targets)[0]
                tmpl = random.choice(self.POISON_REASONS)
                decision = {"action": "poison", "poison_target": target}
                reasoning = tmpl.format(target=target)
            else:
                decision = {"action": "skip"}
                reasoning = "我还没有确定的目标，毒药先留着，避免误伤好人。"
        else:
            decision = {"action": "skip"}
            reasoning = "没有需要行动的情况，继续观察。"

        self._remember(observable_state, decision, reasoning)
        return decision

    def on_speech(self, observable_state: dict) -> str:
        alive = observable_state["alive_players"]

        speeches = observable_state.get("current_speeches", [])
        for speech in speeches:
            pid = speech["player_id"]
            if pid != self.player_id and pid in alive:
                if "狼" in speech["content"] or "出" in speech["content"]:
                    self._suspicious.add(pid)

        # 有怀疑对象时用包含具体编号的发言模板
        sus_alive = sorted(self._suspicious & set(alive))
        wlist = '、'.join(str(p) for p in sus_alive[:3])
        speech = random.choice(self.SPEECH_TEMPLATES).format(wlist=wlist) if wlist else random.choice(self.SPEECH_TEMPLATES[:3])

        reasoning = (
            f"作为女巫，我要隐藏身份观察局势。"
            f"目前怀疑{self._suspicious}号有狼面，继续听发言确认。"
        )
        self._remember(observable_state, {"action": "speech", "content": speech}, reasoning)
        return speech

    def on_vote(self, observable_state: dict) -> dict:
        alive = observable_state["alive_players"]
        suspects = self._suspicious & set(alive)
        if suspects:
            target = list(suspects)[0]
            reasoning = f"我投{target}号，他是我重点怀疑的狼人，不能放走。"
        else:
            targets = [p for p in alive if p != self.player_id and p not in self._saved]
            target = random.choice(targets) if targets else random.choice(
                [p for p in alive if p != self.player_id]
            )
            reasoning = f"没有明确目标，先投{target}号观察他的反应和票型。"

        self._remember(observable_state, {"action": "vote", "target": target}, reasoning)
        return {"target": target}

    def on_hunter_shot(self, observable_state: dict) -> dict:
        return {"target": None}

    def summarize(self) -> str:
        night_actions = [m for m in self._memory if m["phase"] == "night"]
        saves = sum(1 for m in night_actions if isinstance(m.get("action"), dict) and m["action"].get("action") == "save")
        poisons = sum(1 for m in night_actions if isinstance(m.get("action"), dict) and m["action"].get("action") == "poison")
        return (
            f"女巫总结：怀疑过 {len(self._suspicious)} 人，"
            f"救过 {len(self._saved)} 人（{saves}次），用毒 {poisons} 次。"
        )
