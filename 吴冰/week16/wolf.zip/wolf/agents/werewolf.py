import random
from .base import BaseAgent


class WerewolfAgent(BaseAgent):
    """狼人 Agent — 有夜间技能、知道同伴是谁"""

    KILL_REASONS = [
        "我选择杀{target}号，他发言积极可能是强势神职带队，先砍掉好人的核心。",
        "我选择杀{target}号，他比较低调一直不表态，可能是深水好人不好找。",
        "我选择杀{target}号，他上一轮踩人很准，留着迟早会查到我们。",
        "我选择杀{target}号，趁早削弱好人的数量优势，制造轮次领先。",
        "我选择杀{target}号，他逻辑清晰分析到位，这种玩家越早走越好。",
        "我选择杀{target}号，他目前没人怀疑，把他做焦点的成本最低。",
    ]

    SPEECH_TEMPLATES = [
        "我觉得{target}号行为很可疑，上一轮发言逻辑有问题，可能是一匹狼。强烈建议大家出{target}号。",
        "我怀疑{target}号是狼人，他的发言很奇怪一直在转移话题，大家这轮跟我投{target}号。",
        "我是好人，{target}号一直在带节奏踩人，我觉得他大概率是狼，不能被他带偏。",
        "现在场上局势不明朗，但{target}号肯定有问题，建议归票{target}号，先走一个明狼。",
        "大家分析一下上一轮的投票，{target}号的票型很诡异，跟风投了关键票。",
        "我昨晚想了很久，{target}号的发言有好几处矛盾，他解释不清楚就是铁狼。",
    ]

    SUSPECT_TARGETS = {}  # class-level hint for follow logic

    def on_night(self, observable_state: dict) -> dict:
        alive = observable_state["alive_players"]
        partners = observable_state.get("werewolf_partners", [])
        wolves = set(partners) | {self.player_id}
        targets = [p for p in alive if p not in wolves]
        target = random.choice(targets) if targets else random.choice(alive)

        reason_tmpl = random.choice(self.KILL_REASONS)
        reasoning = (
            f"我是狼人，我的同伴是{list(partners)}号。存活非狼玩家有{targets}，"
            f"{reason_tmpl.format(target=target)}"
        )
        self._remember(observable_state, {"action": "kill", "target": target}, reasoning)
        return {"target": target}

    def on_speech(self, observable_state: dict) -> str:
        alive = observable_state["alive_players"]
        partners = observable_state.get("werewolf_partners", [])
        wolves = set(partners) | {self.player_id}
        suspects = [p for p in alive if p not in wolves]

        target = random.choice(suspects) if suspects else random.choice(alive) if alive else None

        # 轮次影响策略
        rnd = observable_state.get("round", 1)
        alive_non_wolves = len(suspects)
        if alive_non_wolves <= 2:
            speech = (
                f"场上没多少人了，我建议仔细分析每一票的票型。"
                f"不过我认为{target}号的嫌疑最大。"
            )
            reasoning = (
                f"快要残局了，我先模糊焦点不要暴露自己。"
                f"踩{target}号转移视线，让好人互相怀疑。"
            )
        else:
            speech = random.choice(self.SPEECH_TEMPLATES).format(target=target)
            reasoning = (
                f"我要伪装成好人，踩{target}号转移好人视线。"
                f"说我是清白、指责别人是狼人，可以迷惑好人的判断。"
            )

        self._remember(observable_state, {"action": "speech", "content": speech}, reasoning)
        return speech

    VOTE_REASONS = [
        "我要投票给{target}号，他是好人，票走一个好人狼人就离胜利更近一步。",
        "投{target}号出局，减少好人的轮次优势。这把只要隐藏好就能赢。",
        "我投{target}号，他是站对边的平民，先把他清除出局。",
        "归票{target}号，他发言偏民，出了他不亏。",
    ]

    def on_vote(self, observable_state: dict) -> dict:
        alive = observable_state["alive_players"]
        partners = observable_state.get("werewolf_partners", [])
        wolves = set(partners) | {self.player_id}
        candidates = [p for p in alive if p not in wolves]
        target = random.choice(candidates) if candidates else random.choice(alive)

        reasoning = random.choice(self.VOTE_REASONS).format(target=target)
        self._remember(observable_state, {"action": "vote", "target": target}, reasoning)
        return {"target": target}

    def on_hunter_shot(self, observable_state: dict) -> dict:
        return {"target": None}

    def summarize(self) -> str:
        night_kills = [
            m for m in self._memory
            if isinstance(m.get("action"), dict) and m["action"].get("action") == "kill"
        ]
        victims = [m["action"]["target"] for m in night_kills]
        return (
            f"本局存活至第{len(self._memory) // 3 + 1}轮，"
            f"参与 {len(night_kills)} 次夜间刀人，目标为{'、'.join(f'{v}号' for v in victims)}。"
        )
