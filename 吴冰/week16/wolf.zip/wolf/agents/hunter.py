import random
from .base import BaseAgent


class HunterAgent(BaseAgent):
    """猎人 Agent — 没有夜间技能，临死可以开枪带走一人"""

    SPEECH_CAN_SHOOT = [
        "我是猎人，手里有枪！我怀疑{sus}号，别让我找到铁狼，否则一枪带走不亏。",
        "我是好人，大家归票要慎重。我有开枪权，谁冲我投我就带谁走。",
        "我觉得{sus}号有问题，大家注意一下他的发言逻辑。我手里有枪心里不慌。",
        "这轮出人要想清楚，我是猎人不怕被刀，关键是要找出狼人。",
        "{sus}号的发言有几处矛盾点，解释不过来的话我会考虑开枪。",
    ]
    SPEECH_NO_SHOOT = [
        "我站边预言家，跟着预言家的验人走。没枪了只能靠逻辑。",
        "我是好人，希望大家理性投票，不要被狼人带节奏。我身份已明帮不上更多了。",
        "大家加油分析，我虽然没有技能了但还是会好好投票。",
    ]

    def __init__(self, player_id: int):
        super().__init__(player_id)
        self._suspicious: set[int] = set()
        self._can_shoot: bool = True

    def on_night(self, observable_state: dict) -> dict:
        return {}

    def on_speech(self, observable_state: dict) -> str:
        alive = observable_state["alive_players"]
        can_shoot = observable_state.get("can_shoot", True)

        speeches = observable_state.get("current_speeches", [])
        for speech in speeches:
            pid = speech["player_id"]
            if pid != self.player_id and pid in alive:
                if "狼" in speech["content"]:
                    self._suspicious.add(pid)

        if can_shoot:
            sus_list = list(self._suspicious)[:2]
            sus_str = '、'.join(str(p) for p in sus_list) if sus_list else "某"
            speech = random.choice(self.SPEECH_CAN_SHOOT).format(sus=sus_str)
            reasoning = (
                f"我有开枪权，可以强势带队甚至威胁狼人。"
                f"目前怀疑{self._suspicious}号，发言强硬可以吸引焦点。"
            )
        else:
            speech = random.choice(self.SPEECH_NO_SHOOT)
            reasoning = (
                f"我已经开过枪或失去技能了，低调发言跟着好人走。"
                f"仍然怀疑{self._suspicious}号，但只能靠投票解决问题。"
            )

        self._remember(observable_state, {"action": "speech", "content": speech}, reasoning)
        return speech

    def on_vote(self, observable_state: dict) -> dict:
        alive = observable_state["alive_players"]
        suspects = self._suspicious & set(alive)
        if suspects:
            target = list(suspects)[0]
            reasoning = f"我投{target}号，他是我一直怀疑的狼人，这一票不会改。"
        else:
            targets = [p for p in alive if p != self.player_id]
            target = random.choice(targets) if targets else None
            reasoning = f"没有明确怀疑对象，先投{target}号看看票型。"

        self._remember(observable_state, {"action": "vote", "target": target}, reasoning)
        return {"target": target} if target else {}

    def on_hunter_shot(self, observable_state: dict) -> dict:
        can_shoot = observable_state.get("can_shoot", False)
        if not can_shoot:
            return {"target": None}

        alive = observable_state["alive_players"]
        suspects = self._suspicious & set(alive)
        if suspects:
            target = list(suspects)[0]
            reasoning = f"我临死开枪带走{target}号，他是我一直怀疑的狼人，死也要拉个垫背的！"
        else:
            targets = [p for p in alive if p != self.player_id]
            target = random.choice(targets) if targets else None
            reasoning = f"没有明确目标，但死了不能白死，随机带走{target}号。"

        self._remember(observable_state, {"action": "hunter_shot", "target": target}, reasoning)
        return {"target": target}

    def summarize(self) -> str:
        return (
            f"猎人总结：怀疑过 {len(self._suspicious)} 人。"
            + ("开过枪不亏本！" if not self._can_shoot else "全程没机会开枪。")
        )
