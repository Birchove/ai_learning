import random
from .base import BaseAgent


class VillagerAgent(BaseAgent):
    """平民 Agent — 没有技能，全靠发言和投票"""

    SPEECH_FOLLOW_SEER = [
        "我站边预言家！{wolf_id}号被查杀了，肯定是狼人，今天全票出{wolf_id}号。",
        "预言家发查杀了，{wolf_id}号是铁狼，没什么好说的，直接出！",
        "听预言家的！{wolf_id}号查杀走一个，平民跟着归票走就对了。",
    ]
    SPEECH_PEACE = [
        "昨晚是平安夜，说明女巫救人或者狼人空刀。大家理性发言，不要过早站边。",
        "平安夜是个好消息，至少核心神职还在。但也不要放松警惕，狼人可能在迷惑我们。",
    ]
    SPEECH_GENERIC = [
        "我是好人，目前还在听发言阶段，暂时没有明确的目标。大家多分析一下票型。",
        "我觉得上一轮的投票信息很关键，大家分析一下投票逻辑，看看谁在跟风出票。",
        "我是平民，没有夜间信息，但我相信自己的判断。今天跟预言家归票走。",
        "大家冷静分析，不要被情绪带偏了。我暂时没有特别怀疑的人，但{target}号有点值得关注。",
        "我是铁好人，各位神职带好队，平民紧跟就是最大的贡献。",
        "这一轮发言的质量比上一轮差，有人在浑水摸鱼，我建议严查几个划水的玩家。",
    ]

    def __init__(self, player_id: int):
        super().__init__(player_id)
        self._trust: set[int] = set()
        self._suspect: set[int] = set()

    def on_night(self, observable_state: dict) -> dict:
        return {}

    def on_speech(self, observable_state: dict) -> str:
        alive = observable_state["alive_players"]

        # 分析发言建立信任/怀疑
        speeches = observable_state.get("current_speeches", [])
        for speech in speeches:
            pid = speech["player_id"]
            if pid == self.player_id or pid not in alive:
                continue
            if "好人" in speech["content"] and "我是" in speech["content"]:
                self._trust.add(pid)
            for other_pid in alive:
                if other_pid != pid and f"{other_pid}号" in speech["content"]:
                    if "狼" in speech["content"]:
                        if random.random() < 0.3:
                            self._suspect.add(pid)
                        break

        # 如果有查杀信息，直接站边预言家
        check_list = observable_state.get("seer_checks", [])
        for c in check_list:
            if c["result"] == "狼人":
                speech = random.choice(self.SPEECH_FOLLOW_SEER).format(wolf_id=c['player_id'])
                reasoning = (
                    f"预言家查杀{c['player_id']}号是狼人，铁逻辑。"
                    f"平民跟着预言家走是最稳的策略。"
                )
                self._remember(observable_state,
                               {"action": "speech", "content": speech}, reasoning)
                return speech

        # 无查杀信息
        death_info = observable_state.get("death_info", "")
        if "平安夜" in death_info:
            speech = random.choice(self.SPEECH_PEACE)
            reasoning = "平安夜说明女巫救了人或者狼人策略空刀，局势尚不明朗先观察。"
        else:
            # 有怀疑对象时在发言中点名
            sus_alive = (self._suspect & set(alive))
            if sus_alive:
                target = random.choice(list(sus_alive))
                speech = random.choice(self.SPEECH_GENERIC).format(target=target)
            else:
                speech = random.choice(self.SPEECH_GENERIC[:4]).format(target="某")
            reasoning = (
                f"作为平民，我没有夜间信息，只能通过发言和投票找狼。"
                f"目前信任{self._trust}号，怀疑{self._suspect}号。"
            )

        self._remember(observable_state, {"action": "speech", "content": speech}, reasoning)
        return speech

    def on_vote(self, observable_state: dict) -> dict:
        alive = observable_state["alive_players"]

        suspects = self._suspect & set(alive)
        if suspects:
            target = list(suspects)[0]
            reasoning = f"我投{target}号，一直在我的怀疑名单里，发言和票型都不做好。"
        else:
            targets = [p for p in alive if p not in self._trust and p != self.player_id]
            if targets:
                target = random.choice(targets)
                reasoning = f"我投{target}号，他不在我的信任名单里，排坑先走一个。"
            else:
                targets = [p for p in alive if p != self.player_id]
                target = random.choice(targets) if targets else None
                reasoning = f"没有明确目标，先投{target}号。"

        self._remember(observable_state, {"action": "vote", "target": target}, reasoning)
        return {"target": target} if target else {}

    def on_hunter_shot(self, observable_state: dict) -> dict:
        return {"target": None}

    def summarize(self) -> str:
        return (
            f"平民总结：信任 {len(self._trust)} 人，怀疑 {len(self._suspect)} 人。"
            f"投票正确率{'(估算)' if self._suspect else '无明确方向。'}"
        )
