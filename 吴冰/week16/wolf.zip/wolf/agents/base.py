from __future__ import annotations
from typing import Any, Optional


class BaseAgent:
    """Agent 基类 - 所有角色 Agent 的抽象接口"""

    def __init__(self, player_id: int):
        self.player_id = player_id
        # 记忆：记录每轮看到的信息、自己的行动和思考过程
        self._memory: list[dict[str, Any]] = []

    def _remember(self, observation: dict, action: Any = None,
                  reasoning: Optional[str] = None) -> None:
        self._memory.append({
            "round": observation.get("round", 0),
            "phase": observation.get("phase", ""),
            "action": action,
            "reasoning": reasoning or "",
        })

    def get_timeline(self) -> list[dict]:
        """返回有序的玩家个人时间线"""
        return [
            {
                "round": m["round"],
                "phase": m["phase"],
                "action": m.get("action"),
                "reasoning": m.get("reasoning", ""),
            }
            for m in self._memory
        ]

    def on_night(self, observable_state: dict) -> dict:
        """夜间行动，返回决策 dict"""
        raise NotImplementedError

    def on_speech(self, observable_state: dict) -> str:
        """白天发言，返回发言内容"""
        raise NotImplementedError

    def on_vote(self, observable_state: dict) -> dict:
        """投票阶段，返回 {'target': player_id}"""
        raise NotImplementedError

    def on_hunter_shot(self, observable_state: dict) -> dict:
        """猎人开枪决策，返回 {'target': player_id} 或 {'target': None}"""
        raise NotImplementedError

    def summarize(self) -> str:
        """赛后总结：回顾自己的表现"""
        return f"[{self.__class__.__name__}] 暂无总结"
