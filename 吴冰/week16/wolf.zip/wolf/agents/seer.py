import random
from .base import BaseAgent


class SeerAgent(BaseAgent):
    """预言家 Agent — 每晚验人，白天带队找狼"""

    INVESTIGATE_REASONS = [
        "我从存活未验的玩家中选择查验{target}号。他发言不多但态度中立，值得查一下底牌。",
        "我选择查验{target}号，他上一轮带节奏比较明显，是狼是神需要确认。",
        "我选择查验{target}号，他一直没进入大家视野，可能是深水狼需要排坑。",
        "我选择查验{target}号，他的投票逻辑有疑点，验清楚比较好带队。",
        "我选择查验{target}号，他主动踩过几个人，验证他的身份能帮好人理清局势。",
    ]

    def __init__(self, player_id: int):
        super().__init__(player_id)
        self._checked: set[int] = set()
        self._known_wolves: set[int] = set()
        self._known_good: set[int] = set()

    def on_night(self, observable_state: dict) -> dict:
        alive = observable_state["alive_players"]
        candidates = [p for p in alive if p not in self._checked and p != self.player_id]
        target = random.choice(candidates) if candidates else None

        if target:
            self._checked.add(target)
            reason_tmpl = random.choice(self.INVESTIGATE_REASONS)
            reasoning = reason_tmpl.format(target=target)
        else:
            reasoning = "所有存活玩家都已查验过，今晚没有需要查验的目标。"

        self._remember(observable_state, {"action": "investigate", "target": target}, reasoning)
        return {"target": target}

    def on_speech(self, observable_state: dict) -> str:
        alive = observable_state["alive_players"]

        # 更新已知信息
        checks = observable_state.get("seer_checks", [])
        for c in checks:
            pid = c["player_id"]
            if pid not in self._checked:
                self._checked.add(pid)
            if c["result"] == "狼人":
                self._known_wolves.add(pid)
            else:
                self._known_good.add(pid)

        # 有查杀就报查杀
        alive_wolves = self._known_wolves & set(alive)
        if alive_wolves:
            wolf = list(alive_wolves)[0]
            reasoning = (
                f"我昨晚验出{wolf}号是狼人，铁查杀！必须报出带队出他。"
                f"这是我的核心职责，好人需要我的信息来投票。"
                + (f"如果{wolf}号自爆吞警徽，说明他是铁狼不解释。" if random.random() < 0.3 else "")
            )
            speech = (
                f"我是预言家！昨晚查验{wolf}号，他是狼人！铁查杀！"
                f"今天全票出{wolf}号，不要分票。"
            )
            self._remember(observable_state, {"action": "speech", "content": speech}, reasoning)
            return speech

        # 报金水
        alive_good = self._known_good & set(alive)
        if alive_good:
            good = list(alive_good)[0]
            next_target = next(
                (p for p in alive if p not in self._checked and p != self.player_id),
                None
            )
            reasoning = (
                f"我验出{good}号是金水，他是好人可以完全信任。"
                + (f"今晚计划验{next_target}号，进一步扩大信息优势。" if next_target
                   else "场上没有需要查验的人了，后面就靠逻辑分析。")
            )
            speech = (
                f"我是预言家，昨晚查验{good}号是好人（金水）。"
                f"今天我会听{good}号的站边。"
                + (f"今晚计划验{next_target}号。" if next_target else "没有查验目标了，大家靠自己分析。")
            )
            self._remember(observable_state, {"action": "speech", "content": speech}, reasoning)
            return speech

        target = next(
            (p for p in alive if p not in self._checked and p != self.player_id),
            None
        )
        if target:
            reasoning = (
                f"我还没有明确的查验信息，先跳预言家给好人报查验计划，"
                f"让大家知道我今晚会验{target}号，引导局势走向。"
            )
            speech = (
                f"我是预言家，昨晚查验了{target}号，结果不便公布。"
                f"大家先发言分析，我会在归票时给出信息。"
            )
        else:
            reasoning = "我已经查验过所有人了，现在只能靠逻辑推理帮好人找狼。"
            speech = "我是预言家，场上基本明了了，大家跟我一起归票狼人。"

        self._remember(observable_state, {"action": "speech", "content": speech}, reasoning)
        return speech

    def on_vote(self, observable_state: dict) -> dict:
        alive = observable_state["alive_players"]
        alive_wolves = self._known_wolves & set(alive)
        if alive_wolves:
            target = list(alive_wolves)[0]
            reasoning = f"{target}号是我昨晚验出的铁狼，必须一票投出他。"
            self._remember(observable_state, {"action": "vote", "target": target}, reasoning)
            return {"target": target}

        suspects = [p for p in alive if p != self.player_id and p not in self._known_good]
        if suspects:
            target = random.choice(suspects)
            reasoning = (
                f"没有明确的查杀，我选择投{target}号。"
                f"他还没被我验证过，嫌疑相对较大。排除法也要一个个来。"
            )
        else:
            target = random.choice([p for p in alive if p != self.player_id])
            reasoning = f"场上都是金水了，但必须投一个，先走{target}号吧。"

        self._remember(observable_state, {"action": "vote", "target": target}, reasoning)
        return {"target": target}

    def on_hunter_shot(self, observable_state: dict) -> dict:
        return {"target": None}

    def summarize(self) -> str:
        wolves_found = len(self._known_wolves)
        goods_found = len(self._known_good)
        return (
            f"查验 {len(self._checked)} 人，"
            f"查出 {wolves_found} 狼、{goods_found} 好。"
            + (f"精准命中{round(wolves_found/max(len(self._checked),1)*100)}%查杀率！" if self._checked else "")
        )
