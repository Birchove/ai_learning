from dataclasses import dataclass, field
from typing import Optional
from .enums import Role


@dataclass
class Player:
    player_id: int
    name: str
    role: Role

    # 生存状态
    is_alive: bool = True
    is_poisoned: bool = False  # 被女巫毒死（猎人被毒不能开枪）

    # 预言家查验结果（仅预言家知道）
    seer_result: Optional[bool] = None  # True=好人, False=狼人

    # 女巫相关
    is_silver_water: bool = False  # 银水（被女巫救过）

    # 出局时翻牌
    revealed_role: Optional[Role] = None

    # 死亡追踪
    death_cause: str = ""  # 死亡原因描述
    death_round: int = 0   # 死于第几轮

    def __hash__(self) -> int:
        return hash(self.player_id)
