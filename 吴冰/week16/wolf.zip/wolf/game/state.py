from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Dict, List
from .enums import GamePhase, NightStep, Camp, Role
from .player import Player


@dataclass
class DeathInfo:
    """每夜/每天的死亡信息"""
    wolf_kill_target: Optional[int] = None   # 狼人刀的人
    witch_save_target: Optional[int] = None  # 女巫救的人（银水）
    witch_poison_target: Optional[int] = None  # 女巫毒的人
    hunter_shoot_target: Optional[int] = None  # 猎人带走的人
    voted_out_target: Optional[int] = None   # 被投票放逐的人

    @property
    def night_deaths(self) -> list[int]:
        """夜里真正死亡的人（被狼刀且未被救 + 被毒）"""
        dead = []
        if self.wolf_kill_target is not None and self.wolf_kill_target != self.witch_save_target:
            dead.append(self.wolf_kill_target)
        if self.witch_poison_target is not None:
            dead.append(self.witch_poison_target)
        return sorted(dead)

    @property
    def day_death_message(self) -> str:
        dead = self.night_deaths
        if not dead:
            return "昨晚是平安夜，无人死亡"
        names = [f"{pid}号玩家" for pid in dead]
        return f"昨晚 {'、'.join(names)} 死亡"

    @property
    def is_silent_night(self) -> bool:
        return len(self.night_deaths) == 0


@dataclass
class Speech:
    player_id: int
    content: str
    round_number: int

    def __str__(self) -> str:
        return f"{self.player_id}号: {self.content}"


@dataclass
class GameState:
    round_number: int = 1
    phase: GamePhase = GamePhase.NIGHT
    night_step: Optional[NightStep] = NightStep.WEREWOLF_KILL

    players: list[Player] = field(default_factory=list)
    alive_player_ids: list[int] = field(default_factory=list)

    # 夜间行动中间状态
    wolf_kill_target: Optional[int] = None
    seer_target: Optional[int] = None
    witch_save_target: Optional[int] = None
    witch_poison_target: Optional[int] = None

    # 女巫药水
    witch_has_antidote: bool = True
    witch_has_poison: bool = True

    # 猎人开枪权（被毒则失去）
    hunter_can_shoot: bool = True

    # 当前轮次的发言和投票
    current_speeches: list[Speech] = field(default_factory=list)
    current_votes: dict[int, int] = field(default_factory=dict)  # 投票人 -> 被投票人

    # 死亡信息
    last_death_info: DeathInfo = field(default_factory=DeathInfo)

    # 全局日志
    game_log: list[str] = field(default_factory=list)

    # 游戏结束
    winner: Optional[Camp] = None

    # 狼人自爆标记（自爆后直接进入黑夜）
    wolf_exploded: bool = False

    # ===== 辅助属性 =====

    @property
    def alive_players(self) -> list[Player]:
        return [p for p in self.players if p.is_alive]

    @property
    def player_map(self) -> dict[int, Player]:
        return {p.player_id: p for p in self.players}

    @property
    def game_over(self) -> bool:
        return self.phase == GamePhase.GAME_OVER

    def get_player(self, pid: int) -> Player:
        return self.player_map[pid]

    def alive_count(self, role_filter=None) -> int:
        ps = self.alive_players
        if role_filter:
            ps = [p for p in ps if p.role == role_filter]
        return len(ps)

    def log(self, msg: str) -> None:
        self.game_log.append(f"[R{self.round_number}|{self.phase.value}] {msg}")

    def add_player(self, name: str, role) -> Player:
        pid = len(self.players) + 1
        p = Player(player_id=pid, name=name, role=role)
        self.players.append(p)
        self.alive_player_ids.append(pid)
        return p

    def eliminate(self, pid: int, cause: str, revealed_role: bool = False) -> None:
        """将一名玩家标记为出局"""
        p = self.get_player(pid)
        if not p.is_alive:
            return
        p.is_alive = False
        p.death_cause = cause
        p.death_round = self.round_number
        self.alive_player_ids.remove(pid)
        if revealed_role:
            p.revealed_role = p.role
        self.log(f"{pid}号玩家出局（{cause}）{'，翻牌：' + p.role.display_name() if revealed_role else ''}")

    def get_werewolf_ids(self) -> list[int]:
        return [p.player_id for p in self.players if p.role == Role.WEREWOLF and p.is_alive]

    def get_seer_id(self) -> Optional[int]:
        for p in self.players:
            if p.role == Role.SEER and p.is_alive:
                return p.player_id
        return None

    def get_witch_id(self) -> Optional[int]:
        for p in self.players:
            if p.role == Role.WITCH and p.is_alive:
                return p.player_id
        return None

    def get_hunter_id(self) -> Optional[int]:
        for p in self.players:
            if p.role == Role.HUNTER and p.is_alive:
                return p.player_id
        return None
