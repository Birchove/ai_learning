from __future__ import annotations
import sys
from dataclasses import dataclass, field
from typing import Optional


def _safe_print(*args, **kwargs):
    """确保终端能正确输出，处理编码问题"""
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        # 回退：用 ASCII 替换无法编码的字符
        text = " ".join(str(a) for a in args)
        text = text.encode(
            sys.stdout.encoding or "utf-8", errors="replace"
        ).decode(sys.stdout.encoding or "utf-8", errors="replace")
        print(text, **kwargs)


@dataclass
class GameLogEntry:
    round: int
    phase: str
    content: str
    details: dict = field(default_factory=dict)


class GameLogger:
    def __init__(self):
        self.entries: list[GameLogEntry] = []

    def log(self, round: int, phase: str, content: str, **details) -> None:
        entry = GameLogEntry(round=round, phase=phase, content=content, details=details)
        self.entries.append(entry)
        _safe_print(f"[R{round}|{phase}] {content}")

    def print_summary(self) -> None:
        _safe_print("\n" + "=" * 60)
        _safe_print("                     对  局  总  结")
        _safe_print("=" * 60)
        for entry in self.entries:
            _safe_print(f"[R{entry.round}|{entry.phase}] {entry.content}")

    def get_role_action_log(self, player_id: int) -> list[str]:
        return [
            f"[R{e.round}|{e.phase}] {e.content}"
            for e in self.entries
            if e.details.get("player_id") == player_id
        ]
