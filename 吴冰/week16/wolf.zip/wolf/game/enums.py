from enum import Enum


class Role(Enum):
    WEREWOLF = "werewolf"
    SEER = "seer"
    WITCH = "witch"
    HUNTER = "hunter"
    VILLAGER = "villager"

    def display_name(self) -> str:
        return {
            Role.WEREWOLF: "狼人",
            Role.SEER: "预言家",
            Role.WITCH: "女巫",
            Role.HUNTER: "猎人",
            Role.VILLAGER: "平民",
        }[self]


class Camp(Enum):
    WEREWOLF = "werewolf"
    GOOD = "good"

    def display_name(self) -> str:
        return {Camp.WEREWOLF: "狼人阵营", Camp.GOOD: "好人阵营"}[self]


def camp_of(role: Role) -> Camp:
    return Camp.WEREWOLF if role == Role.WEREWOLF else Camp.GOOD


class GamePhase(Enum):
    NIGHT = "night"
    DAY_SPEECH = "day_speech"
    DAY_VOTE = "day_vote"
    GAME_OVER = "game_over"


class NightStep(Enum):
    WEREWOLF_KILL = "werewolf_kill"
    SEER_INVESTIGATE = "seer_investigate"
    WITCH_ACTION = "witch_action"
