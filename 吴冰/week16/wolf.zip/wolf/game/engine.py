from __future__ import annotations
from typing import Optional, Callable, TYPE_CHECKING
from .enums import Role, Camp, camp_of, GamePhase, NightStep
from .state import GameState, DeathInfo, Speech
from .player import Player
from .logger import GameLogger

if TYPE_CHECKING:
    from agents.base import BaseAgent


class GameEngine:
    def __init__(self, state: GameState, logger: GameLogger):
        self.state = state
        self.logger = logger
        self.agent_map: dict[int, "BaseAgent"] = {}  # player_id -> agent

    def register_agent(self, agent: "BaseAgent") -> None:
        self.agent_map[agent.player_id] = agent

    # ================================================================
    #  初始设置
    # ================================================================

    def setup_players(self) -> None:
        """创建7名玩家并分配角色"""
        roles = [
            Role.WEREWOLF, Role.WEREWOLF,
            Role.SEER,
            Role.WITCH,
            Role.HUNTER,
            Role.VILLAGER, Role.VILLAGER,
        ]
        name_map = {
            Role.WEREWOLF: "狼人",
            Role.SEER: "预言家",
            Role.WITCH: "女巫",
            Role.HUNTER: "猎人",
            Role.VILLAGER: "平民",
        }
        for i, role in enumerate(roles):
            pid = i + 1
            player = self.state.add_player(
                name=f"玩家{pid}（{name_map[role]}）", role=role
            )
            self.logger.log(1, "setup", f"玩家{pid} 身份：{role.display_name()}", player_id=pid)

    # ================================================================
    #  给 Agent 的可观测状态（信息隔离）
    # ================================================================

    def _observable_state(self, player_id: int) -> dict:
        """构造某玩家能看到的信息"""
        p = self.state.get_player(player_id)
        info = {
            "round": self.state.round_number,
            "phase": self.state.phase.value,
            "my_id": player_id,
            "my_role": p.role.value,
            "alive_players": sorted(self.state.alive_player_ids),
            "all_players": sorted(p.player_id for p in self.state.players),
            "current_speeches": [
                {"player_id": s.player_id, "content": s.content}
                for s in self.state.current_speeches
            ],
        }

        # 所有玩家知道昨晚死讯
        if self.state.last_death_info:
            info["death_info"] = self.state.last_death_info.day_death_message

        # 狼人知道自己的同伴
        if p.role == Role.WEREWOLF:
            info["werewolf_partners"] = [
                pid for pid in self.state.get_werewolf_ids() if pid != player_id
            ]

        # 预言家知道自己的查验结果
        if p.role == Role.SEER:
            checked = []
            for other in self.state.players:
                if other.seer_result is not None:
                    checked.append({
                        "player_id": other.player_id,
                        "result": "好人" if other.seer_result else "狼人",
                    })
            info["seer_checks"] = checked

        # 女巫知道今晚被刀的人
        if p.role == Role.WITCH and self.state.phase == GamePhase.NIGHT:
            wolf_target = self.state.wolf_kill_target
            if wolf_target is not None:
                info["wolf_kill_target"] = wolf_target
            info["antidote_remaining"] = self.state.witch_has_antidote
            info["poison_remaining"] = self.state.witch_has_poison
            # 银水信息
            silver = [p.player_id for p in self.state.players if p.is_silver_water]
            if silver:
                info["silver_water"] = silver

        # 猎人知道自己能否开枪
        if p.role == Role.HUNTER:
            info["can_shoot"] = self.state.hunter_can_shoot

        return info

    # ================================================================
    #  主游戏循环
    # ================================================================

    def run_game(self) -> GameState:
        self.logger.log(1, "setup", "========== 游戏开始 ==========")
        self.logger.log(1, "setup", f"存活玩家：{self.state.alive_player_ids}")

        while not self.state.game_over:
            self._run_night()
            if self.state.game_over:
                break
            self._run_day()

        self._announce_winner()
        return self.state

    # ================================================================
    #  夜晚阶段
    # ================================================================

    def _run_night(self) -> None:
        s = self.state
        s.phase = GamePhase.NIGHT
        s.last_death_info = DeathInfo()  # 重置死亡信息
        s.current_speeches = []
        s.current_votes = {}
        s.wolf_exploded = False

        self.logger.log(s.round_number, "night",
                        f"======= 第{s.round_number}晚 =======")

        # 1. 狼人刀人
        self._step_wolf_kill()
        if s.game_over:
            return

        # 2. 预言家验人
        self._step_seer_investigate()

        # 3. 女巫行动
        self._step_witch_action()

        # 结算夜间死亡
        self._resolve_night_deaths()

    def _step_wolf_kill(self) -> None:
        s = self.state
        s.night_step = NightStep.WEREWOLF_KILL
        wolf_ids = s.get_werewolf_ids()

        if not wolf_ids:
            # 狼人全灭，好人胜利
            s.winner = Camp.GOOD
            s.phase = GamePhase.GAME_OVER
            return

        # 狼人共同决策（取第一个狼人的决策，因为他们是共同商量）
        # 实际上，我们让每个狼人独立投票，取多数
        targets = []
        for wid in wolf_ids:
            obs = self._observable_state(wid)
            decision = self.agent_map[wid].on_night(obs)
            targets.append(decision.get("target"))

        # 取最多狼人选择的 target
        from collections import Counter
        target_counts = Counter(t for t in targets if t is not None)
        if target_counts:
            s.wolf_kill_target = target_counts.most_common(1)[0][0]
            for wid in wolf_ids:
                self.logger.log(s.round_number, "night",
                                f"狼人{ wid } 投票杀 { s.wolf_kill_target }号",
                                player_id=wid)
            self.logger.log(s.round_number, "night",
                            f"狼人决定杀死 {s.wolf_kill_target}号玩家")
        else:
            self.logger.log(s.round_number, "night", "狼人没有行动")

    def _step_seer_investigate(self) -> None:
        s = self.state
        s.night_step = NightStep.SEER_INVESTIGATE
        seer_id = s.get_seer_id()
        if seer_id is None:
            return

        obs = self._observable_state(seer_id)
        decision = self.agent_map[seer_id].on_night(obs)
        target = decision.get("target")

        if target and target in s.alive_player_ids:
            target_player = s.get_player(target)
            is_good = camp_of(target_player.role) == Camp.GOOD
            target_player.seer_result = is_good
            result_str = "好人" if is_good else "狼人"
            s.seer_target = target
            self.logger.log(s.round_number, "night",
                            f"预言家查验 {target}号 → {result_str}",
                            player_id=seer_id)

    def _step_witch_action(self) -> None:
        s = self.state
        s.night_step = NightStep.WITCH_ACTION
        witch_id = s.get_witch_id()
        if witch_id is None:
            return
        if not s.witch_has_antidote and not s.witch_has_poison:
            return

        obs = self._observable_state(witch_id)
        decision = self.agent_map[witch_id].on_night(obs)
        action = decision.get("action")  # "save", "poison", "skip"

        if action == "save" and s.witch_has_antidote and s.wolf_kill_target is not None:
            s.witch_save_target = s.wolf_kill_target
            s.witch_has_antidote = False
            s.get_player(s.wolf_kill_target).is_silver_water = True
            self.logger.log(s.round_number, "night",
                            f"女巫使用解药救活 {s.wolf_kill_target}号",
                            player_id=witch_id)

        poison_target = decision.get("poison_target")
        if action == "poison" and s.witch_has_poison and poison_target:
            s.witch_poison_target = poison_target
            s.witch_has_poison = False
            self.logger.log(s.round_number, "night",
                            f"女巫使用毒药毒杀 {poison_target}号",
                            player_id=witch_id)

    def _resolve_night_deaths(self) -> None:
        s = self.state
        s.night_step = None

        deaths = []
        # 被狼刀且女巫没救
        if s.wolf_kill_target is not None and s.wolf_kill_target != s.witch_save_target:
            deaths.append(s.wolf_kill_target)
        # 被女巫毒
        if s.witch_poison_target is not None:
            p = s.get_player(s.witch_poison_target)
            if p.role == Role.HUNTER and p.is_alive:
                s.hunter_can_shoot = False
            deaths.append(s.witch_poison_target)

        # 去重后统一淘汰
        for dead_id in sorted(set(deaths)):
            if s.get_player(dead_id).is_alive:
                cause = "被狼人杀害" if dead_id == s.wolf_kill_target else "被女巫毒杀"
                s.eliminate(dead_id, cause)

        s.last_death_info = DeathInfo(
            wolf_kill_target=s.wolf_kill_target,
            witch_save_target=s.witch_save_target,
            witch_poison_target=s.witch_poison_target,
        )

        if deaths:
            self.logger.log(s.round_number, "night",
                            f"夜间死亡：{'、'.join(f'{d}号' for d in sorted(set(deaths)))}")
        else:
            self.logger.log(s.round_number, "night", "昨晚是平安夜")

        # 猎人被刀可以开枪
        for dead_id in set(deaths):
            self._check_hunter_shot(dead_id, died_by="night_kill")

        # 检查胜负
        self._check_win_condition()

    # ================================================================
    #  白天阶段
    # ================================================================

    def _run_day(self) -> None:
        s = self.state
        if s.game_over:
            return

        # 狼人自爆检查（由 speech 阶段触发）
        s.phase = GamePhase.DAY_SPEECH
        self.logger.log(s.round_number, "day",
                        f"======= 第{s.round_number}天 =======")

        # 公布死讯
        self.logger.log(s.round_number, "day", s.last_death_info.day_death_message)

        if len(s.alive_player_ids) <= 1:
            self._check_win_condition()
            return

        # 发言阶段
        self._run_speech_phase()
        if s.game_over or s.wolf_exploded:
            return

        # 投票阶段
        self._run_vote_phase()
        if s.game_over:
            return

        s.round_number += 1

    def _run_speech_phase(self) -> None:
        s = self.state
        s.phase = GamePhase.DAY_SPEECH
        self.logger.log(s.round_number, "day", "--- 发言阶段 ---")

        # 按玩家编号顺序发言
        for pid in sorted(s.alive_player_ids):
            obs = self._observable_state(pid)
            speech_content = self.agent_map[pid].on_speech(obs)
            speech = Speech(player_id=pid, content=speech_content, round_number=s.round_number)
            s.current_speeches.append(speech)
            self.logger.log(s.round_number, "speech",
                            f"{pid}号发言：{speech_content}",
                            player_id=pid)

            # 狼人自爆检查
            if s.wolf_exploded:
                self.logger.log(s.round_number, "speech",
                                f"{pid}号狼人自爆！")
                s.eliminate(pid, "狼人自爆")
                s.wolf_exploded = True
                self._check_win_condition()
                return

    def _run_vote_phase(self) -> None:
        s = self.state
        s.phase = GamePhase.DAY_VOTE
        s.current_votes = {}
        self.logger.log(s.round_number, "day", "--- 投票阶段 ---")

        # 每个存活玩家投票（不能投自己，不能弃权）
        for pid in sorted(s.alive_player_ids):
            obs = self._observable_state(pid)
            vote_result = self.agent_map[pid].on_vote(obs)
            target = vote_result.get("target")
            if target and target in s.alive_player_ids and target != pid:
                s.current_votes[pid] = target
                self.logger.log(s.round_number, "vote",
                                f"{pid}号 投票给 {target}号",
                                player_id=pid)

        # 统计投票
        if not s.current_votes:
            self.logger.log(s.round_number, "vote", "无人投票，平安日")
            return

        from collections import Counter
        vote_counts = Counter(s.current_votes.values())
        max_votes = vote_counts.most_common(1)[0][1]
        candidates = [pid for pid, count in vote_counts.items() if count == max_votes]

        if len(candidates) > 1:
            self.logger.log(s.round_number, "vote",
                            f"平票：{'、'.join(f'{c}号' for c in candidates)}，无人出局")
            return

        eliminated = candidates[0]
        s.last_death_info.voted_out_target = eliminated
        s.eliminate(eliminated, "被投票放逐", revealed_role=True)

        # 猎人被票死可以开枪
        self._check_hunter_shot(eliminated, died_by="vote")
        self._check_win_condition()

    # ================================================================
    #  猎人开枪
    # ================================================================

    def _check_hunter_shot(self, pid: int, died_by: str) -> None:
        s = self.state
        player = s.get_player(pid)
        if player.role != Role.HUNTER or not s.hunter_can_shoot:
            return

        # 猎人临死开枪
        obs = self._observable_state(pid)
        shot_result = self.agent_map[pid].on_hunter_shot(obs)
        target = shot_result.get("target")

        if target and target in s.alive_player_ids and target != pid:
            s.last_death_info.hunter_shoot_target = target
            s.eliminate(target, f"被猎人带走")
            self.logger.log(s.round_number, "day",
                            f"猎人{pid}号开枪带走 {target}号",
                            player_id=pid)
        else:
            self.logger.log(s.round_number, "day",
                            f"猎人{pid}号选择不开枪",
                            player_id=pid)

        s.hunter_can_shoot = False  # 开枪机会只有一次

    # ================================================================
    #  胜负判定
    # ================================================================

    def _check_win_condition(self) -> None:
        s = self.state
        alive = s.alive_players

        if not alive:
            return

        werewolf_alive = any(p.role == Role.WEREWOLF for p in alive)
        good_alive = any(p.role != Role.WEREWOLF for p in alive)

        if not werewolf_alive:
            s.winner = Camp.GOOD
            s.phase = GamePhase.GAME_OVER
            self.logger.log(s.round_number, "game_over", "所有狼人出局，好人阵营获胜！")
            return

        # 狼人胜利条件：所有平民出局 或 所有神职出局
        villager_alive = any(p.role == Role.VILLAGER for p in alive)
        god_alive = any(p.role in (Role.SEER, Role.WITCH, Role.HUNTER) for p in alive)

        if not villager_alive:
            s.winner = Camp.WEREWOLF
            s.phase = GamePhase.GAME_OVER
            self.logger.log(s.round_number, "game_over", "所有平民出局，狼人阵营获胜！")
            return

        if not god_alive:
            s.winner = Camp.WEREWOLF
            s.phase = GamePhase.GAME_OVER
            self.logger.log(s.round_number, "game_over", "所有神职出局，狼人阵营获胜！")
            return

    def _announce_winner(self) -> None:
        s = self.state
        if s.winner:
            self.logger.log(s.round_number, "game_over", "=" * 40)
            self.logger.log(s.round_number, "game_over",
                            f"[胜者] {s.winner.display_name()} 获胜！")
            self.logger.log(s.round_number, "game_over", "=" * 40)
            self.logger.log(s.round_number, "game_over", "最终存活玩家：")
            for p in s.alive_players:
                self.logger.log(s.round_number, "game_over",
                                f"  {p.player_id}号 - {p.name}")
            self.logger.log(s.round_number, "game_over", "所有玩家身份：")
            for p in s.players:
                status = "存活" if p.is_alive else "出局"
                self.logger.log(s.round_number, "game_over",
                                f"  {p.player_id}号 - {p.name} [{status}]")
