import { useState } from 'react'
import { useGameStore } from '@/stores/gameStore'
import GameBoard from '@/components/GameBoard/GameBoard'
import Header from '@/components/Layout/Header'
import StatusBar from '@/components/Layout/StatusBar'
import ReplayPanel from '@/components/Replay/ReplayPanel'
import type { WatchMode } from '@/types/game'

console.log('[App] module loaded')

const sampleEvents = [
  { type: 'phase', phase: 'night', day: 1 },
  { type: 'night_action', player_id: 'player_9', role: 'werewolf', action: 'kill', target: 'player_4' },
  { type: 'phase', phase: 'day', day: 1 },
  { type: 'death', player_id: 'player_4', reason: 'kill', day: 1, has_last_words: true, role: 'villager' },
  { type: 'speech', player_id: 'player_1', text: '我是预言家，昨晚查了 player_3 是好人。', role: 'seer' },
  { type: 'speech', player_id: 'player_2', text: '我觉得 player_5 像是狼人，发言太激进。', role: 'villager' },
  { type: 'vote', player_id: 'player_1', target: 'player_5', day: 1 },
  { type: 'vote', player_id: 'player_2', target: 'player_5', day: 1 },
  { type: 'game_end', winner: 'village', survivors: ['player_1', 'player_2', 'player_3'] },
]

function App() {
  const [gameId, setGameId] = useState<string>('')
  const store = useGameStore()
  const { watchMode, setWatchMode, connect, setReplayEvents } = store
  console.log('[App] render, watchMode:', watchMode)

  const handleStartWatch = (mode: WatchMode) => {
    console.log('[App] handleStartWatch called, mode:', mode)
    setWatchMode(mode)
    console.log('[App] setWatchMode called')
    if (mode === 'replay') {
      console.log('[App] setting sample events, sampleEvents length:', sampleEvents.length)
      setReplayEvents(sampleEvents as any)
      console.log('[App] setReplayEvents called')
    }
  }

  const handleConnect = () => {
    if (gameId) {
      connect(gameId)
    }
  }

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col">
      <Header />

      <main className="flex-1 p-6">
        {watchMode === null ? (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-center mb-8">选择观战模式</h2>

            <div className="grid grid-cols-3 gap-6">
              <button
                onClick={() => handleStartWatch('ai_battle')}
                className="p-6 bg-gray-800 rounded-lg hover:bg-gray-700 transition text-left group"
              >
                <h3 className="text-xl font-bold mb-2 group-hover:text-yellow-400">纯 AI 对战</h3>
                <p className="text-gray-400">所有角色均由 AI 控制，观赏 AI 之间的博弈策略</p>
              </button>

              <button
                onClick={() => handleStartWatch('mixed')}
                className="p-6 bg-gray-800 rounded-lg hover:bg-gray-700 transition text-left group"
              >
                <h3 className="text-xl font-bold mb-2 group-hover:text-yellow-400">人机混战</h3>
                <p className="text-gray-400">选择一个或多个角色参与游戏，与 AI 同台竞技</p>
              </button>

              <button
                onClick={() => {
                  console.log('[App] replay button clicked')
                  handleStartWatch('replay')
                }}
                className="p-6 bg-gray-800 rounded-lg hover:bg-gray-700 transition text-left group"
              >
                <h3 className="text-xl font-bold mb-2 group-hover:text-yellow-400">对局回放</h3>
                <p className="text-gray-400">加载历史对局，回放完整博弈过程</p>
              </button>
            </div>

            {/* 连接游戏 */}
            <div className="mt-8 p-6 bg-gray-800 rounded-lg">
              <h3 className="text-lg font-semibold mb-4">或连接已有游戏</h3>
              <div className="flex gap-4">
                <input
                  type="text"
                  placeholder="输入游戏 ID"
                  value={gameId}
                  onChange={(e) => setGameId(e.target.value)}
                  className="flex-1 px-4 py-2 bg-gray-700 rounded text-white placeholder-gray-400"
                />
                <button
                  onClick={handleConnect}
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-500 rounded font-medium"
                >
                  连接
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col">
            <StatusBar />
            {watchMode === 'replay' ? (
              <ReplayPanel />
            ) : (
              <GameBoard />
            )}
          </div>
        )}
      </main>
    </div>
  )
}

export default App