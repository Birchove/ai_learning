import { create } from 'zustand'
import type { GameState, GameEvent, Player, WatchMode } from '@/types/game'

interface GameStore extends GameState {
  // 模式
  watchMode: WatchMode
  setWatchMode: (mode: WatchMode) => void

  // 连接
  connect: (gameId: string) => void
  disconnect: () => void

  // 游戏状态更新
  updatePhase: (phase: string, day: number) => void
  addEvent: (event: GameEvent) => void
  setPlayers: (players: Player[]) => void
  updatePlayer: (playerId: string, updates: Partial<Player>) => void

  // 投票
  clearVotes: () => void

  // 游戏结束
  endGame: (winner: string, survivors: string[]) => void

  // 重置
  reset: () => void

  // 回放
  replayEvents: GameEvent[]
  setReplayEvents: (events: GameEvent[]) => void
  replayIndex: number
  setReplayIndex: (index: number) => void
}

const initialState: GameState = {
  game_id: '',
  day: 1,
  phase: 'night',
  players: [],
  events: [],
  winner: undefined,
  is_game_over: false,
  is_connected: false,
  is_replay_mode: false,
}

export const useGameStore = create<GameStore>((set, get) => ({
  ...initialState,
  watchMode: 'ai_battle',
  replayEvents: [],
  replayIndex: 0,

  setWatchMode: (mode) => set({ watchMode: mode, is_replay_mode: mode === 'replay' }),

  connect: (gameId) => set({ game_id: gameId, is_connected: true }),

  disconnect: () => set({ is_connected: false }),

  updatePhase: (phase, day) => set({ phase, day }),

  addEvent: (event) => set((state) => ({
    events: [...state.events.slice(-100), event]  // 保留最近100条
  })),

  setPlayers: (players) => set({ players }),

  updatePlayer: (playerId, updates) => set((state) => ({
    players: state.players.map(p =>
      p.player_id === playerId ? { ...p, ...updates } : p
    )
  })),

  clearVotes: () => set((state) => ({
    players: state.players.map(p => ({ ...p, voted_for: undefined }))
  })),

  endGame: (winner, survivors) => set({
    winner,
    is_game_over: true,
    phase: 'game_over',
    players: get().players.map(p => ({
      ...p,
      is_alive: survivors.includes(p.player_id)
    }))
  }),

  reset: () => set(initialState),

  setReplayEvents: (events) => set({ replayEvents: events, replayIndex: 0 }),

  setReplayIndex: (index) => set({ replayIndex: index }),
}))