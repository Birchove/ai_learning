// 游戏事件类型
export type GameEvent =
  | PhaseEvent
  | SpeechEvent
  | VoteEvent
  | DeathEvent
  | NightActionEvent
  | GameEndEvent
  | ConnectEvent
  | PlayersEvent

export interface PhaseEvent {
  type: 'phase'
  phase: 'night' | 'day' | 'speak' | 'vote' | 'last_words' | 'result' | 'game_over'
  day: number
  start?: string
}

export interface SpeechEvent {
  type: 'speech'
  player_id: string
  text: string
  seq?: number
  role?: string
}

export interface VoteEvent {
  type: 'vote'
  player_id: string
  target: string | null
  day: number
  round?: number
}

export interface DeathEvent {
  type: 'death'
  player_id: string
  reason: 'kill' | 'vote' | 'poison' | 'shoot'
  day: number
  has_last_words?: boolean
  role?: string  // 死亡后才显示
}

export interface NightActionEvent {
  type: 'night_action'
  player_id: string
  role: string
  action: string
  target: string | null
  result?: string
}

export interface GameEndEvent {
  type: 'game_end'
  winner: 'village' | 'werewolf'
  survivors: string[]
}

export interface ConnectEvent {
  type: 'connect'
  game_id: string
  player_id?: string
}

export interface PlayersEvent {
  type: 'players'
  players: Player[]
}

// 玩家状态
export interface Player {
  player_id: string
  name: string
  role?: string  // 死亡后才显示
  is_alive: boolean
  is_sheriff: boolean
  voted_for?: string
  speech_text?: string
  is_speaking?: boolean
}

// 游戏状态
export interface GameState {
  game_id: string
  day: number
  phase: string
  players: Player[]
  events: GameEvent[]
  winner?: string
  is_game_over: boolean
  is_connected: boolean
  is_replay_mode: boolean
}

// 投票记录
export interface VoteRecord {
  voter_id: string
  target_id: string | null
  day: number
  round: number
}

// 观战模式
export type WatchMode = 'ai_battle' | 'mixed' | 'replay'

// 回放状态
export interface ReplayState {
  is_playing: boolean
  current_index: number
  speed: number  // 0.5, 1, 2
  events: GameEvent[]
}