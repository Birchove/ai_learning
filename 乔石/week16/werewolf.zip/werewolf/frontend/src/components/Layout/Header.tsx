import { useGameStore } from '@/stores/gameStore'

export default function Header() {
  const { game_id, day, phase, is_connected, is_game_over, winner } = useGameStore()

  return (
    <header className="bg-gray-800 border-b border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h1 className="text-2xl font-bold text-yellow-400">AI 狼人杀</h1>
          {is_connected && (
            <span className="text-sm text-gray-400">游戏ID: {game_id}</span>
          )}
        </div>

        <div className="flex items-center gap-4">
          {is_game_over ? (
            <div className={`px-4 py-2 rounded font-bold ${
              winner === 'village' ? 'bg-green-600' : 'bg-red-600'
            }`}>
              {winner === 'village' ? '好人胜利' : '狼人胜利'}
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-gray-400">第 {day} 天</span>
              <PhaseBadge phase={phase} />
            </div>
          )}

          <ConnectionStatus connected={is_connected} />
        </div>
      </div>
    </header>
  )
}

function PhaseBadge({ phase }: { phase: string }) {
  const config: Record<string, { label: string; class: string }> = {
    night: { label: '黑夜', class: 'bg-blue-900 text-blue-300' },
    day: { label: '白天', class: 'bg-orange-500 text-white' },
    speak: { label: '发言', class: 'bg-green-600 text-white' },
    vote: { label: '投票', class: 'bg-purple-600 text-white' },
    last_words: { label: '遗言', class: 'bg-gray-600 text-white' },
    result: { label: '结算', class: 'bg-gray-700 text-white' },
    game_over: { label: '结束', class: 'bg-gray-800 text-white' },
  }

  const { label, class: className } = config[phase] || { label: phase, class: 'bg-gray-600' }

  return (
    <span className={`px-3 py-1 rounded-full text-sm font-medium ${className}`}>
      {label}
    </span>
  )
}

function ConnectionStatus({ connected }: { connected: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <span className={`w-2 h-2 rounded-full ${connected ? 'bg-green-500' : 'bg-red-500'}`} />
      <span className="text-sm text-gray-400">{connected ? '已连接' : '未连接'}</span>
    </div>
  )
}