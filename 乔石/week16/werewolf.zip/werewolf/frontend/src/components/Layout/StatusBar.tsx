import { useGameStore } from '@/stores/gameStore'
import type { GameEvent } from '@/types/game'

const sampleEvents = [
  { type: 'phase', phase: 'night', day: 1 },
  { type: 'night_action', player_id: 'player_9', role: 'werewolf', action: 'kill', target: 'player_4' },
  { type: 'phase', phase: 'day', day: 1 },
  { type: 'death', player_id: 'player_4', reason: 'kill', day: 1, has_last_words: true, role: 'villager' },
  { type: 'speech', player_id: 'player_1', text: '我是预言家，昨晚查了 player_3 是好人。', role: 'seer' },
  { type: 'speech', player_id: 'player_2', text: '我觉得 player_5 像是狼人，发言太激进。', role: 'villager' },
  { type: 'vote', player_id: 'player_1', target: 'player_5', day: 1 },
  { type: 'vote', player_id: 'player_2', target: 'player_5', day: 1 },
  { type: 'game_end', winner: 'village', survivors: ['player_1', 'player_2', 'player_3'] },
]

export default function StatusBar() {
  const { players, events, setWatchMode, setReplayEvents, reset } = useGameStore()

  const alivePlayers = players.filter(p => p.is_alive)

  const recentEvents = events.slice(-5)

  return (
    <div className="bg-gray-800 border-b border-gray-700 px-6 py-3">
      <div className="flex items-center justify-between">
        {/* 存活玩家 */}
        <div className="flex items-center gap-4">
          <span className="text-gray-400 text-sm">存活:</span>
          <div className="flex gap-1">
            {alivePlayers.map(p => (
              <span
                key={p.player_id}
                className="px-2 py-1 bg-green-700 rounded text-xs"
                title={p.name}
              >
                {p.player_id.replace('player_', 'P')}
              </span>
            ))}
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setWatchMode('ai_battle')}
            className="px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm"
          >
            AI对战
          </button>
          <button
            onClick={() => {
              setWatchMode('replay')
              setReplayEvents(sampleEvents as any)
            }}
            className="px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm"
          >
            回放
          </button>
          <button
            onClick={reset}
            className="px-3 py-1 bg-red-700 hover:bg-red-600 rounded text-sm"
          >
            退出
          </button>
        </div>

        {/* 最近事件 */}
        <div className="flex items-center gap-2">
          <span className="text-gray-400 text-sm">最近:</span>
          <div className="flex gap-1">
            {recentEvents.map((e, i) => (
              <EventBadge key={i} event={e} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function EventBadge({ event }: { event: GameEvent }) {
  const config: Record<string, { label: string; color: string }> = {
    phase: { label: '阶段', color: 'bg-blue-600' },
    speech: { label: '发言', color: 'bg-green-600' },
    vote: { label: '投票', color: 'bg-purple-600' },
    death: { label: '死亡', color: 'bg-red-600' },
    night_action: { label: '夜刀', color: 'bg-orange-600' },
    game_end: { label: '结束', color: 'bg-gray-600' },
  }

  const { label, color } = config[event.type] || { label: event.type, color: 'bg-gray-600' }

  return (
    <span className={`px-2 py-1 ${color} rounded text-xs`}>
      {label}
    </span>
  )
}