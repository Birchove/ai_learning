import { useEffect, useState, useCallback } from 'react'
import { useGameStore } from '@/stores/gameStore'
import type { GameEvent } from '@/types/game'

export default function ReplayPanel() {
  // 使用 selector 确保响应式
  const replayEvents = useGameStore(state => state.replayEvents)
  const setReplayIndex = useGameStore(state => state.setReplayIndex)
  const setPlayers = useGameStore(state => state.setPlayers)
  const addEvent = useGameStore(state => state.addEvent)
  const updatePhase = useGameStore(state => state.updatePhase)
  const updatePlayer = useGameStore(state => state.updatePlayer)
  const endGame = useGameStore(state => state.endGame)

  const [isPlaying, setIsPlaying] = useState(false)
  const [speed, setSpeed] = useState(1)
  const [localIndex, setLocalIndex] = useState(0)
  const [isInitialized, setIsInitialized] = useState(false)

  console.log('[ReplayPanel] render, replayEvents:', replayEvents.length, 'localIndex:', localIndex, 'isPlaying:', isPlaying)

  // 初始化玩家
  useEffect(() => {
    console.log('[ReplayPanel] initializing players')
    if (!isInitialized && replayEvents.length > 0) {
      const initPlayers = Array.from({ length: 12 }, (_, i) => ({
        player_id: `player_${i + 1}`,
        name: `玩家${i + 1}`,
        is_alive: true,
        is_sheriff: false,
      }))
      setPlayers(initPlayers)
      setIsInitialized(true)
    }
  }, [replayEvents.length, isInitialized, setPlayers])

  // 播放单个事件
  const playEvent = useCallback((event: GameEvent, index: number) => {
    console.log('[ReplayPanel] playEvent', index, event.type)
    addEvent(event)

    const e = event as any
    switch (event.type) {
      case 'phase':
        updatePhase(e.phase, e.day)
        break

      case 'players':
        if (e.players) setPlayers(e.players)
        break

      case 'vote':
        if (e.player_id && e.target !== undefined) {
          updatePlayer(e.player_id, { voted_for: e.target || undefined })
        }
        break

      case 'death':
        if (e.player_id) {
          updatePlayer(e.player_id, { is_alive: false, role: e.role })
        }
        break

      case 'game_end':
        console.log('[playEvent] game_end, winner:', e.winner, 'survivors:', e.survivors)
        endGame(e.winner, e.survivors)
        break

      case 'speech':
        if (e.player_id) {
          updatePlayer(e.player_id, { speech_text: e.text, is_speaking: true, role: e.role })
        }
        break

      case 'night_action':
        // 夜间动作 - 可以显示但不更新玩家状态
        break

      default:
        break
    }
  }, [addEvent, updatePhase, setPlayers, updatePlayer, endGame])

  // 自动播放
  useEffect(() => {
    console.log('[useEffect] isPlaying:', isPlaying, 'localIndex:', localIndex, 'total:', replayEvents.length)
    if (!isPlaying) {
      console.log('[useEffect] not playing, returning')
      return
    }
    if (localIndex >= replayEvents.length) {
      console.log('[useEffect] playback finished (localIndex >= length)')
      setIsPlaying(false)
      return
    }
    if (localIndex >= replayEvents.length - 1 && replayEvents[localIndex]?.type === 'game_end') {
      console.log('[useEffect] reached last event (game_end)')
      setIsPlaying(false)
      return
    }

    console.log('[useEffect] scheduling timeout for index', localIndex)
    const timer = setTimeout(() => {
      console.log('[timeout] firing for index', localIndex, 'length', replayEvents.length)
      // Guard against index out of bounds
      if (localIndex >= replayEvents.length) {
        console.log('[timeout] index out of bounds, skipping')
        setIsPlaying(false)
        return
      }
      const event = replayEvents[localIndex]
      if (event) {
        console.log('[timeout] playing event', event.type)
        playEvent(event, localIndex)
        const nextIndex = localIndex + 1
        setLocalIndex(nextIndex)
        setReplayIndex(nextIndex)
      }
    }, 1000 / speed)

    return () => {
      console.log('[useEffect cleanup] clearing timeout')
      clearTimeout(timer)
    }
  }, [isPlaying, localIndex, replayEvents, speed, playEvent, setReplayIndex])

  const handlePlay = () => {
    console.log('[handlePlay] called, events:', replayEvents.length)
    if (replayEvents.length === 0) {
      console.log('[handlePlay] no events!')
      return
    }

    // 重置状态
    const initPlayers = Array.from({ length: 12 }, (_, i) => ({
      player_id: `player_${i + 1}`,
      name: `玩家${i + 1}`,
      is_alive: true,
      is_sheriff: false,
    }))
    setPlayers(initPlayers)
    setReplayIndex(0)
    setLocalIndex(0)
    setIsPlaying(true)
    console.log('[handlePlay] done, isPlaying set to true')
  }

  const handlePause = () => {
    console.log('[handlePause]')
    setIsPlaying(false)
  }

  const handleStep = (dir: 1 | -1) => {
    const newIndex = Math.max(0, Math.min(replayEvents.length - 1, localIndex + dir))
    setLocalIndex(newIndex)
    setReplayIndex(newIndex)
    if (newIndex < replayEvents.length) {
      playEvent(replayEvents[newIndex], newIndex)
    }
  }

  const handleSeek = (index: number) => {
    const initPlayers = Array.from({ length: 12 }, (_, i) => ({
      player_id: `player_${i + 1}`,
      name: `玩家${i + 1}`,
      is_alive: true,
      is_sheriff: false,
    }))
    setPlayers(initPlayers)
    setLocalIndex(0)
    setReplayIndex(0)

    for (let i = 0; i <= index; i++) {
      if (replayEvents[i]) {
        playEvent(replayEvents[i], i)
      }
    }
    setLocalIndex(index)
    setReplayIndex(index)
  }

  const progress = replayEvents.length > 1
    ? (localIndex / (replayEvents.length - 1)) * 100
    : 0

  const currentEvent = replayEvents[localIndex]

  return (
    <div className="flex-1 flex flex-col p-6">
      {/* 播放控制 */}
      <div className="bg-gray-800 rounded-lg p-4 mb-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <button
              onClick={isPlaying ? handlePause : handlePlay}
              className="px-4 py-2 bg-yellow-600 hover:bg-yellow-500 rounded font-medium"
            >
              {isPlaying ? '⏸️ 暂停' : '▶️ 播放'}
            </button>

            <button onClick={() => handleStep(-1)} disabled={localIndex <= 0} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded disabled:opacity-50">
              ⏮️ 上一个
            </button>

            <button onClick={() => handleStep(1)} disabled={localIndex >= replayEvents.length - 1} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded disabled:opacity-50">
              ⏭️ 下一个
            </button>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-gray-400">速度:</span>
            <div className="flex gap-1">
              {[0.5, 1, 2].map(s => (
                <button key={s} onClick={() => setSpeed(s)} className={`px-3 py-1 rounded ${speed === s ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'}`}>
                  {s}x
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 时间轴 */}
        <div className="relative h-12 bg-gray-700 rounded">
          <div className="absolute left-0 top-0 h-full bg-blue-500 rounded-l transition-all duration-300" style={{ width: `${progress}%` }} />
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-sm">
            {replayEvents.length > 0 ? `${localIndex + 1} / ${replayEvents.length}` : '无事件'}
          </div>
        </div>

        {/* 事件列表 */}
        <div className="mt-4 max-h-32 overflow-y-auto">
          <div className="flex gap-2 flex-wrap">
            {replayEvents.map((_, index) => (
              <button key={index} onClick={() => handleSeek(index)} className={`px-2 py-1 rounded text-xs ${index === localIndex ? 'bg-blue-600 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}>
                {index + 1}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 当前事件详情 */}
      <div className="bg-gray-800 rounded-lg p-4 flex-1">
        <h3 className="text-lg font-semibold mb-4">当前事件</h3>
        {currentEvent ? <EventDetail event={currentEvent} /> : <div className="text-gray-500">暂无事件 - 点击播放开始回放</div>}
      </div>
    </div>
  )
}

function EventDetail({ event }: { event: GameEvent }) {
  const typeLabels: Record<string, string> = {
    phase: '阶段切换', speech: '发言', vote: '投票', death: '死亡',
    night_action: '夜间动作', game_end: '游戏结束', players: '玩家列表', connect: '连接',
  }
  const e = event as any

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-4">
        <span className="px-3 py-1 bg-blue-600 rounded-full text-sm">{typeLabels[event.type] || event.type}</span>
        <span className="text-gray-400 text-sm">
          {event.type === 'phase' && `第 ${e.day} 天 - ${e.phase}`}
          {event.type === 'speech' && `${e.player_id}: ${e.text}`}
          {event.type === 'vote' && `${e.player_id} 投给了 ${e.target || '弃票'}`}
          {event.type === 'death' && `${e.player_id} 死亡 (${e.reason})`}
          {event.type === 'game_end' && `胜利方: ${e.winner}`}
          {event.type === 'players' && `共 ${e.players?.length || 0} 名玩家`}
          {event.type === 'night_action' && `${e.player_id} (${e.role}) 进行了 ${e.action}`}
        </span>
      </div>
      {event.type === 'speech' && (
        <div className="p-4 bg-gray-700 rounded-lg">
          <div className="text-sm text-gray-400 mb-1">发言内容</div>
          <div className="text-lg">{e.text}</div>
        </div>
      )}
      {event.type === 'game_end' && (
        <div className={`p-4 rounded-lg ${e.winner === 'village' ? 'bg-green-700' : 'bg-red-700'}`}>
          <div className="text-xl font-bold">{e.winner === 'village' ? '好人胜利' : '狼人胜利'}</div>
          <div className="text-sm mt-1">存活: {(e.survivors || []).join(', ')}</div>
        </div>
      )}
    </div>
  )
}