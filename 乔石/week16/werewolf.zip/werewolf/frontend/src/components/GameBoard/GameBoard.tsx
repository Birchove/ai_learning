import { useState, useEffect } from 'react'
import { useGameStore } from '@/stores/gameStore'

export default function GameBoard() {
  const { players, phase, day } = useGameStore()

  // 12人座次分布 - 上下两排各6人
  const seatPositions = [
    // 顶部 6 人
    { left: 10, top: 5 },
    { left: 25, top: 5 },
    { left: 40, top: 5 },
    { left: 55, top: 5 },
    { left: 70, top: 5 },
    { left: 85, top: 5 },
    // 底部 6 人
    { left: 10, top: 60 },
    { left: 25, top: 60 },
    { left: 40, top: 60 },
    { left: 55, top: 60 },
    { left: 70, top: 60 },
    { left: 85, top: 60 },
  ]

  // 确保有12个位置
  const displayPlayers = [...players]
  while (displayPlayers.length < 12) {
    displayPlayers.push({
      player_id: `empty_${displayPlayers.length}`,
      name: '',
      is_alive: false,
      is_sheriff: false,
    })
  }

  return (
    <div className="relative w-full h-full min-h-[600px] bg-gradient-to-b from-gray-800 to-gray-900 rounded-xl p-8">
      {/* 阶段标题 */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
        <PhaseIndicator phase={phase} day={day} />
      </div>

      {/* 座位 */}
      {displayPlayers.slice(0, 12).map((player, index) => (
        <Seat
          key={player.player_id}
          player={player}
          position={seatPositions[index % 12]}
          index={index}
        />
      ))}

      {/* 中间区域 - 投票板 */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <VoteSummary />
      </div>
    </div>
  )
}

interface SeatProps {
  player: {
    player_id: string
    name: string
    role?: string
    is_alive: boolean
    is_sheriff: boolean
    is_speaking?: boolean
    speech_text?: string
    voted_for?: string
  }
  position: { left: number; top: number }
  index: number
}

function Seat({ player, position, index }: SeatProps) {
  const [showSpeech, setShowSpeech] = useState(false)

  useEffect(() => {
    if (player.speech_text) {
      setShowSpeech(true)
      const timer = setTimeout(() => setShowSpeech(false), 3000)
      return () => clearTimeout(timer)
    }
  }, [player.speech_text])

  if (player.player_id.startsWith('empty_')) {
    return (
      <div
        className="absolute transform -translate-x-1/2"
        style={{ left: `${position.left}%`, top: `${position.top}%` }}
      >
        <div className="w-20 h-28 border-2 border-dashed border-gray-600 rounded-lg opacity-30" />
      </div>
    )
  }

  return (
    <div
      className="absolute transform -translate-x-1/2 -translate-y-1/2"
      style={{ left: `${position.left}%`, top: `${position.top}%` }}
    >
      {/* 发言气泡 */}
      {showSpeech && player.speech_text && (
        <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
          <div className="bg-white text-gray-900 px-4 py-2 rounded-lg shadow-lg max-w-xs">
            <p className="text-sm">{player.speech_text}</p>
          </div>
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-8 border-transparent border-t-white" />
        </div>
      )}

      {/* 玩家卡片 */}
      <div
        className={`
          w-20 h-28 rounded-lg border-2 transition-all
          ${player.is_alive ? 'bg-gray-700 border-gray-600' : 'bg-gray-800 border-gray-700 opacity-60'}
          ${player.is_speaking ? 'ring-4 ring-yellow-400 animate-pulse' : ''}
          ${player.role === 'werewolf' && !player.is_alive ? 'border-red-500' : ''}
        `}
      >
        {/* 座位号 */}
        <div className="absolute -top-3 -left-3 w-7 h-7 bg-gray-600 rounded-full flex items-center justify-center text-sm font-bold">
          {index + 1}
        </div>

        {/* 角色标签 */}
        {player.role && !player.is_alive && (
          <div className={`absolute top-1 right-1 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold
            ${player.role === 'werewolf' ? 'bg-red-600 text-white' : ''}
            ${player.role === 'seer' ? 'bg-blue-600 text-white' : ''}
            ${player.role === 'witch' ? 'bg-purple-600 text-white' : ''}
            ${player.role === 'hunter' ? 'bg-green-600 text-white' : ''}
            ${player.role === 'guardian' ? 'bg-teal-600 text-white' : ''}
            ${player.role === 'idiot' ? 'bg-yellow-600 text-black' : ''}
            ${player.role === 'villager' ? 'bg-gray-500 text-white' : ''}
          `}>
            {player.role[0].toUpperCase()}
          </div>
        )}

        {/* 警长标记 */}
        {player.is_sheriff && (
          <div className="absolute -top-3 -right-3 w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-lg font-bold text-black shadow">
            ⭐
          </div>
        )}

        {/* 玩家名称 */}
        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-center">
          <div className="text-xs text-gray-300 truncate w-16">{player.name || player.player_id}</div>
        </div>

        {/* 死亡标记 */}
        {!player.is_alive && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-4xl text-red-500 opacity-50">💀</div>
          </div>
        )}
      </div>

      {/* 投票箭头 */}
      {player.voted_for && player.is_alive && (
        <VoteArrow />
      )}
    </div>
  )
}

function VoteArrow() {
  return (
    <div className="absolute -right-8 top-1/2 transform -translate-y-1/2 text-xs text-yellow-400">
      →
    </div>
  )
}

function PhaseIndicator({ phase, day }: { phase: string; day: number }) {
  const phaseLabels: Record<string, string> = {
    night: '🌙 黑夜',
    day: '☀️ 白天',
    speak: '💬 发言',
    vote: '🗳️ 投票',
    last_words: '💭 遗言',
    result: '📋 结算',
  }

  return (
    <div className="px-6 py-3 bg-gray-700 rounded-full flex items-center gap-4">
      <span className="text-yellow-400 font-bold">第 {day} 天</span>
      <span className="text-2xl">{phaseLabels[phase] || phase}</span>
    </div>
  )
}

function VoteSummary() {
  const { players } = useGameStore()
  const votes: Record<string, number> = {}

  players.forEach(p => {
    if (p.voted_for) {
      votes[p.voted_for] = (votes[p.voted_for] || 0) + 1
    }
  })

  const voteEntries = Object.entries(votes).sort((a, b) => b[1] - a[1])

  return (
    <div className="bg-gray-800 bg-opacity-90 rounded-lg p-4 min-w-[200px]">
      <div className="text-sm text-gray-400 mb-2">投票统计</div>
      {voteEntries.length === 0 ? (
        <div className="text-gray-500 text-sm">暂无投票</div>
      ) : (
        <div className="space-y-1">
          {voteEntries.slice(0, 5).map(([target, count]) => (
            <div key={target} className="flex items-center justify-between text-sm">
              <span className="text-gray-300">{target}</span>
              <span className="text-yellow-400 font-bold">{count} 票</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}