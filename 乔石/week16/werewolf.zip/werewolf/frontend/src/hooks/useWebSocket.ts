import { useEffect, useRef, useCallback } from 'react'
import { useGameStore } from '@/stores/gameStore'
import type { GameEvent } from '@/types/game'

const WS_URL = import.meta.env.VITE_WS_URL || '/ws/game'

export function useWebSocket(gameId: string | null) {
  const wsRef = useRef<WebSocket | null>(null)
  const reconnectTimeoutRef = useRef<number>()
  const { connect, disconnect, updatePhase, addEvent, updatePlayer, endGame } = useGameStore()

  const handleMessage = useCallback((event: MessageEvent) => {
    try {
      const data: GameEvent = JSON.parse(event.data)

      switch (data.type) {
        case 'phase':
          updatePhase(data.phase, data.day)
          break

        case 'speech':
          updatePlayer(data.player_id, {
            speech_text: data.text,
            is_speaking: true,
            role: data.role
          })
          addEvent(data)
          // 3秒后清除发言状态
          setTimeout(() => {
            updatePlayer(data.player_id, { is_speaking: false })
          }, 3000)
          break

        case 'vote':
          updatePlayer(data.player_id, { voted_for: data.target || undefined })
          addEvent(data)
          break

        case 'death':
          updatePlayer(data.player_id, { is_alive: false, role: data.role })
          addEvent(data)
          break

        case 'night_action':
          addEvent(data)
          break

        case 'game_end':
          endGame(data.winner, data.survivors)
          addEvent(data)
          break

        case 'connect':
          connect(data.game_id)
          break
      }
    } catch (error) {
      console.error('Failed to parse WebSocket message:', error)
    }
  }, [connect, updatePhase, addEvent, updatePlayer, endGame])

  const connect_ = useCallback(() => {
    if (!gameId) return

    const ws = new WebSocket(`${WS_URL}/${gameId}`)

    ws.onopen = () => {
      console.log('WebSocket connected')
      connect(gameId)
    }

    ws.onmessage = handleMessage

    ws.onerror = (error) => {
      console.error('WebSocket error:', error)
    }

    ws.onclose = () => {
      console.log('WebSocket disconnected')
      disconnect()
      // 5秒后重连
      reconnectTimeoutRef.current = window.setTimeout(() => {
        connect_()
      }, 5000)
    }

    wsRef.current = ws
  }, [gameId, handleMessage, connect, disconnect])

  const disconnect_ = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current)
    }
    if (wsRef.current) {
      wsRef.current.close()
      wsRef.current = null
    }
    disconnect()
  }, [disconnect])

  useEffect(() => {
    if (gameId) {
      connect_()
    }

    return () => {
      disconnect_()
    }
  }, [gameId, connect_, disconnect_])

  return {
    send: (data: object) => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify(data))
      }
    },
    isConnected: wsRef.current?.readyState === WebSocket.OPEN,
  }
}