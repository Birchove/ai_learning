/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        werewolf: {
          red: '#dc2626',
          dark: '#1f2937',
          gold: '#f59e0b',
          silver: '#9ca3af',
        },
        role: {
          wolf: '#dc2626',
          seer: '#3b82f6',
          witch: '#8b5cf6',
          hunter: '#22c55e',
          guardian: '#14b8a6',
          idiot: '#eab308',
          villager: '#6b7280',
        },
      },
      animation: {
        'typewriter': 'typewriter 2s steps(40) 1s forwards',
        'fade-in': 'fadeIn 0.3s ease-out',
        'flip': 'flip 0.6s ease-in-out',
        'pulse-slow': 'pulse 2s infinite',
      },
      keyframes: {
        typewriter: {
          '0%': { width: '0' },
          '100%': { width: '100%' },
        },
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        flip: {
          '0%': { transform: 'rotateY(0deg)' },
          '100%': { transform: 'rotateY(180deg)' },
        },
      },
    },
  },
  plugins: [],
}