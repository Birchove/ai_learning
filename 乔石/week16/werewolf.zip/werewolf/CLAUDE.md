# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

AI 狼人杀 — 多智能体协作与博弈系统

多智能体系统，AI Agent 分别扮演狼人、预言家、女巫、猎人、平民等不同角色，在严格的信息不对称约束下独立进行推理、发言与决策。

**核心挑战：**
- 信息隔离：Agent 只能看到自己的角色和公开游戏状态
- 多智能体协作与对抗
- 不确定性下的策略推理与说服
- 回合制对局引擎与胜负裁决

**进阶方向：**
- 前端观战 UI：支持纯 AI 对战或人机混战
- 自演化系统："读懂自己→修改自己→运行自己"
- 评测体系：结果评测、过程评测、Leaderboard

## 前端观战 UI

### 三种模式

**1. 纯 AI 对战**
- 所有 Agent 均由 AI（LLM）扮演
- 用户以观战身份查看实时博弈
- 实时显示各角色的发言、投票、死亡信息

**2. 人机混战**
- 用户可选择一个或多个角色亲自操作
- 人类玩家通过 UI 输入发言与投票
- 系统校验后参与对局，与 AI Agent 同台竞技

**3. 对局回放**
- 加载历史日志（JSON Lines）
- 按时间轴回放对局全过程
- 支持暂停、快进
- 查看各 Agent 的决策思维链（如推理摘要）

### 技术栈

```
前端：React/Vue + Canvas/Three.js
  - 动态卡牌渲染
  - 身份标识（面具/神职图标）
  - 发言气泡动画
  - 投票动画（票型流向）
  - 实时事件流消费

后端：WebSocket 推送
  - /ws/game/{game_id} - 实时游戏状态
  - /ws/spectator/{game_id} - 观战者通道
  - 事件流格式：JSON Lines
```

### WebSocket API

**实时事件格式：**
```json
{"type": "phase", "phase": "night", "day": 1}
{"type": "speech", "player_id": "player_1", "text": "...", "seq": 1}
{"type": "vote", "player_id": "player_2", "target": "player_7"}
{"type": "death", "player_id": "player_7", "reason": "vote"}
{"type": "game_end", "winner": "village", "survivors": [...]}
```

### 关键组件

| 组件 | 功能 |
|------|------|
| **GameBoard** | 主游戏面板，展示12人座位、存活状态 |
| **PlayerCard** | 玩家卡牌，显示身份（死亡后翻转）、投票状态 |
| **SpeechBubble** | 发言气泡，动画展示发言内容 |
| **VotePanel** | 投票面板，展示票数流向动画 |
| **TimelinePlayer** | 回放时间轴，支持暂停/快进/定位 |
| **DecisionChain** | 决策链面板，展示 Agent 推理摘要 |

## 常用命令

```bash
# 安装依赖
uv sync

# 安装开发依赖（pytest、black、ruff）
uv sync --group dev

# 运行服务器
uv run python -m werewolf

# 运行测试
uv run pytest

# 代码检查
uv run ruff check .
uv run black --check .
```

## 代码架构

```
app/
├── main.py                    # FastAPI 入口，WebSocket 支持
├── config.py                  # 板子配置、游戏规则配置
│
├── engine/                    # 对局引擎
│   ├── game.py                # GameEngine：主循环、阶段驱动、胜负判定
│   ├── judge.py               # Judge：夜间结算、投票裁决、规则校验
│   └── phase.py               # PhaseHandler：黑夜/白天/投票各阶段处理
│
├── models/                    # 数据模型（Pydantic）
│   ├── game_state.py          # 游戏全局状态
│   ├── player.py              # 玩家状态（存活/死亡/技能状态）
│   ├── role.py                # 角色定义（狼人/预言家/女巫等）
│   ├── action.py              # 动作定义（刀人/查验/用药等）
│   └── events.py              # 日志事件结构
│
├── agents/                    # 多智能体框架
│   ├── base.py                # RoleAgent：Agent 基类
│   ├── memory.py              # AgentMemory：短时记忆 + 长时记忆
│   ├── strategy.py            # RoleStrategy：角色策略引擎
│   ├── werewolf.py            # WerewolfAgent：狼人（焊跳/刀人/伪装）
│   ├── seer.py                # SeerAgent：预言家（报验/带队）
│   ├── witch.py               # WitchAgent：女巫（用药决策）
│   ├── hunter.py              # HunterAgent：猎人（开枪时机）
│   ├── guardian.py            # GuardianAgent：守卫（守护决策）
│   ├── idiot.py               # IdiotAgent：白痴（翻牌豁免）
│   └── villager.py            # VillagerAgent：平民（抿身份/投票）
│
├── llm/                       # LLM 集成
│   ├── client.py              # LLM 客户端封装（OpenAI/Claude）
│   └── prompts.py             # 各角色发言/决策的 prompt 模板
│
├── communication/             # 通信机制
│   ├── message_bus.py         # MessageBus：广播/私聊/公屏
│   ├── private_channel.py     # 夜间私有信道（各角色私密信息）
│   └── wolf_channel.py        # 狼队频道（狼人夜间协商）
│
├── logs/                      # 结构化日志
│   ├── game_logger.py         # GameLogger：JSON Lines 日志写入
│   └── event_recorder.py      # EventRecorder：事件录制与回放
│
└── api/                       # WebSocket API
    ├── websocket.py           # WebSocket 路由
    ├── game_api.py           # 游戏状态查询
    └── spectator.py          # 观战者接口
```

**核心模块职责：**

| 模块 | 职责 |
|------|------|
| **GameEngine** | 对局主循环，驱动黑夜→白天→投票阶段流转，触发各 Agent 决策 |
| **Judge** | 夜间结算（刀人/查验/用药结果）、投票裁决、胜负条件判定 |
| **PhaseHandler** | 各阶段具体处理：死亡结算、遗言顺序、PK 流程 |
| **RoleAgent** | Agent 基类，包含 on_night_phase/on_day_phase/on_vote 等完整接口 |
| **MessageBus** | 管理公开聊天、狼队频道、私有信道的信息路由 |
| **PrivateChannel** | 严格按角色权限分发夜间私密信息（预言家验人结果、女巫刀口等） |
| **GameLogger** | 将所有对局事件写入 JSON Lines 日志，支持流式输出与存档 |
| **AgentMemory** | 短时记忆（当前对局事件流）+ 长时记忆（跨对局行为模式） |
| **BoardConfig** | 板子配置：角色数量、座位分配、技能限制 |
| **LLMClient** | OpenAI/Claude API 封装，支持多模型切换 |

## 核心模块设计

### 1. 对局引擎

对局引擎是系统的"世界法则"，严格遵循标准狼人杀规则（预女猎白、预女猎守等板子可配置）。

**核心职责：**

- **回合与阶段驱动**：黑夜 → 白天发言 → 投票 → 黄昏遗言，循环至胜负条件触发
- **行动合法性校验**：女巫仅有一瓶解药和毒药、预言家每晚查验一人、猎人刀口开枪等规则校验
- **信息隔离与广播**：黑夜阶段各角色仅接收权限范围内的私密信息；白天阶段所有存活玩家获得公开信息
- **胜负裁决**：实时判定"所有狼人出局"或"神边/民边屠边"等条件

**阶段流转：**
```
黑夜阶段：
  狼人刀人 → 预言家查验 → 女巫用药 → 守卫守护 → （结算夜间动作）

白天阶段：
  死亡宣告 → 遗言 → 公开讨论 → 警长竞选（可选）→ 投票 → 放逐 → 总结发言
```

**支持的板子（可配置）：**
- 标准12人：预女猎白 + 4狼4神4民
- 预女猎守：带守卫替代白痴
- 自定义角色组合

### 2. 多智能体框架

每个 Agent 是独立的智能体实例，具备以下能力模块：

| 模块 | 功能描述 |
|------|----------|
| **角色策略引擎** | 根据当前角色（狼人/预言家/女巫/猎人/平民）加载对应的目标函数与行为约束。例如狼人目标为"伪装好人并存活"，预言家目标为"传递验人信息并带领好人获胜" |
| **信息处理与推理** | 接收对局事件流（夜间私密信息、白天发言、投票记录等），更新内部信念状态，推理场上身份分布 |
| **发言生成器** | 基于当前信念与策略，生成符合角色身份的自然语言发言。需考虑伪装、抿身份、抗推、表水等多种语用目标 |
| **行动决策器** | 在可行动作空间中选择最优动作（如狼人刀人、女巫用药、投票放逐等），输出结构化决策 |
| **记忆系统** | 短时记忆（单局事件流）与长时记忆（跨对局的玩家行为模式），支持信息检索与总结 |

**Agent 接口：** 详见「7. Agent 完整接口」

### 3. 信息隔离机制

严格实现"每个Agent仅知其应知"：

| 场景 | 可获取信息 |
|------|-----------|
| **狼人夜间** | 狼人同伴列表、上一刀口（首夜不知道刀谁） |
| **预言家夜间** | 查验结果（玩家ID + 好/坏） |
| **女巫夜间** | 当晚刀口（首夜不知）、自己的药水状态 |
| **守卫夜间** | 守护目标（不可连续守同一人） |
| **猎人** | 被刀/被票出局时得知死亡原因，可开枪 |
| **白痴** | 被票放逐时翻牌豁免，后续仅能发言不能投票 |
| **白天公开** | 所有存活玩家获得：发言记录、投票记录、死亡公告、警长信息 |

**狼队频道：** 狼人 Agent 之间有独立的"狼队频道"，用于夜间战术协商（刀谁、焊跳策略等）

### 4. 交互与博弈机制

| 机制 | 描述 |
|------|------|
| **警长竞选** | 随机或按板子触发，通过发言与投票产生警长，拥有归票权与1.5票 |
| **发言顺序** | 支持顺时针/逆时针、警长决定死左死右等多种顺序 |
| **投票放逐** | 每位Agent独立投票，可弃票。平票时进入PK发言或直接平安日（可配置） |
| **遗言机制** | 首夜死亡、白天放逐、技能致死等不同情况配置遗言权利 |
| **自爆** | 狼人可在白天选择自爆，放弃发言但带走遗言 |
| **平安夜** | 女巫用解药或守卫守中则无死亡 |

### 5. 结构化日志与可观测性

系统为每局游戏生成完整的结构化日志，支持实时观测与事后复盘。

**日志内容：**

| 类型 | 内容 |
|------|------|
| **回合事件** | 每个阶段的开始/结束时间戳、当前阶段名称 |
| **夜间行动** | 各角色技能施放目标与结果（隐式记录，不暴露给无权限Agent） |
| **发言记录** | Agent发言的完整文本、发言序号、发言者ID、情绪/立场标签（可选） |
| **投票轨迹** | 每位存活Agent的投票选择（票型）及最终结果 |
| **伤亡记录** | 死亡玩家ID、死亡原因（刀/票/技能）、是否上天等 |
| **胜负结果** | 终局状态、各角色Agent存活情况、胜负阵营、存活玩家列表 |

**日志格式：** JSON Lines（.jsonl），每行一个事件对象，便于流式处理与存档

**日志事件示例：**
```json
{"type": "phase", "phase": "night_1", "start": "2026-05-28T10:00:00Z"}
{"type": "night_action", "role": "werewolf", "action": "kill", "target": "player_5"}
{"type": "night_action", "role": "seer", "action": "check", "target": "player_3", "result": "good"}
{"type": "speech", "player_id": "player_1", "text": "我是预言家，昨晚查了player_3是好人...", "seq": 1}
{"type": "vote", "player_id": "player_2", "target": "player_7"}
{"type": "elimination", "player_id": "player_7", "reason": "vote", "has_last_words": true}
{"type": "game_end", "winner": "village", "survivors": ["player_1", "player_2", "player_4"]}
```

**应用场景：**
- 前端观战 UI 基于日志实时驱动动画或事后复盘
- Agent 跨对局行为模式分析
- 评测体系：结果评测、过程评测、Leaderboard

### 6. 数据模型规格

**Phase 枚举：**
```python
class Phase(Enum):
    NIGHT = "night"
    DAY = "day"
    SPEAK = "speak"       # 白天发言阶段
    VOTE = "vote"         # 投票阶段
    LAST_WORDS = "last_words"  # 遗言阶段
    RESULT = "result"     # 结算阶段
    GAME_OVER = "game_over"
```

**Role 枚举：**
```python
class Role(Enum):
    WEREWOLF = "werewolf"
    SEER = "seer"
    WITCH = "witch"
    HUNTER = "hunter"
    GUARDIAN = "guardian"
    IDIOT = "idiot"
    VILLAGER = "villager"
```

**ActionType 枚举：**
```python
class ActionType(Enum):
    KILL = "kill"           # 狼人刀人
    CHECK = "check"         # 预言家查验
    SAVE = "save"           # 女巫救人
    POISON = "poison"       # 女巫毒人
    PROTECT = "protect"     # 守卫守护
    SHOOT = "shoot"         # 猎人开枪
    VOTE = "vote"           # 投票放逐
    SPEAK = "speak"         # 发言
    SHERIFF_ELECT = "sheriff_elect"  # 警长竞选
```

**PlayerState：**
```python
class PlayerState(BaseModel):
    player_id: str
    name: str
    role: Role
    is_alive: bool = True
    is_sheriff: bool = False
    # 角色技能状态
    witch_has_save: bool = True   # 解药
    witch_has_poison: bool = True # 毒药
    guardian_last_protect: str | None = None  # 昨晚守的人ID
    hunter_can_shoot: bool = True
    idiot_revealed: bool = False  # 白痴是否已翻牌
    voted_for: str | None = None  # 本轮投票投了谁
```

**VoteRecord：**
```python
class VoteRecord(BaseModel):
    day_number: int
    round: int
    voter_id: str
    target_id: str | None  # None = 弃票
    is_pk: bool = False
```

**DeathRecord：**
```python
class DeathRecord(BaseModel):
    player_id: str
    day_number: int
    reason: Literal["kill", "vote", "poison", "shoot"]  # 刀/票/毒/枪
    is_revealed: bool = True
    has_last_words: bool = True
```

**NightAction：**
```python
class NightAction(BaseModel):
    player_id: str
    action_type: ActionType
    target_id: str | None = None
    result: str | None = None
```

**GameState：**
```python
class GameState(BaseModel):
    game_id: str
    players: list[PlayerState]
    current_phase: Phase
    day_number: int = 1
    night_actions: dict[str, list[NightAction]] = {}
    vote_records: list[VoteRecord] = []
    death_records: list[DeathRecord] = []
    sheriff_id: str | None = None
    eliminated_player: str | None = None
    last_words_players: list[str] = []
    winner: str | None = None
    is_game_over: bool = False
```

### 7. Agent 完整接口

```python
class RoleAgent:
    role: Role
    player_id: str
    memory: AgentMemory
    strategy: RoleStrategy

    # === 核心接口 ===

    async def on_night_phase(self, game_state: GameState, private_info: PrivateInfo) -> NightAction | None:
        """夜间行动（刀人/查验/用药/守护等）"""

    async def on_day_phase(self, game_state: GameState) -> str:
        """白天发言生成"""

    async def on_vote(self, game_state: GameState) -> str | None:
        """投票决策，返回玩家ID或None（弃票）"""

    async def on_last_words(self) -> str:
        """遗言"""

    async def receive_private_info(self, private_info: PrivateInfo) -> None:
        """接收夜间私有信息并更新记忆"""

    # === 辅助接口 ===

    async def think(self, game_state: GameState, context: dict) -> Action:
        """推理决策"""

    async def update_belief(self, event: GameEvent) -> None:
        """根据事件更新信念状态"""

    async def summarize_memory(self) -> str:
        """总结长时记忆用于 prompt"""
```

**PrivateInfo（夜间私有信息）：**
```python
class PrivateInfo(BaseModel):
    my_role: Role
    my_player_id: str

    # 预言家
    check_result: str | None = None  # "good" or "bad"

    # 女巫
    kill_target: str | None = None   # 当晚刀谁（首夜不知）
    witch_save_remaining: bool = True
    witch_poison_remaining: bool = True

    # 守卫
    guardian_last_protect: str | None = None  # 昨晚守的人（不能连守）
    guardian_cannot_protect: str | None = None  # 等于 last_protect

    # 狼人
    wolf_teammates: list[str] = []
    last_kill_target: str | None = None

    # 猎人与白痴
    hunter_can_shoot: bool = True
    hunter_death_reason: str | None = None  # 被刀/被票，用于判断能否开枪
    idiot_revealed: bool = False
```

**GameEvent：**
```python
class GameEvent(BaseModel):
    type: str  # phase_start/phase_end/speech/vote/death/reveal
    data: dict
    timestamp: datetime
```

### 8. 夜间结算流程（Judge）

每夜结算顺序：
```
1. 守卫守护 → 记录 guard_target
2. 狼人刀人 → 记录 kill_target
3. 女巫救人 → 检查是否守中、守中则不死
4. 女巫毒人 → 记录 poison_target
5. 预言家查验 → 记录 check_result
6. 死亡结算：
   - 若女巫救人/守卫守中 → 无死亡
   - 否则 kill_target 死亡
   - 若女巫毒人 → poison_target 死亡
7. 猎人开枪：
   - 若死者是猎人且死于刀/毒 → 可选择开枪
8. 胜负判定：
   - 所有狼人阵亡 → 好人胜利
   - 狼人数量 >= 好人数量 → 狼人胜利
```

**平安夜判定：**
- 守卫守护目标 = 狼人刀人目标 → 守中，无死亡
- 女巫使用解药 → 无死亡（与守卫守中互斥）
- 守卫守中 + 女巫救人同时发生 → 以女巫解药优先，守卫守中不生效

**猎人开枪规则：**
- 死亡原因为刀或毒时触发（被票不死）
- 猎人选择开枪目标，若目标是狼人则狼人死
- 猎人死后若无遗言权则直接出局

### 9. 板子配置结构

```python
class BoardConfig(BaseModel):
    name: str  # "预女猎白", "预女猎守", "自定义"
    total_players: int = 12
    roles: list[RoleConfig]

class RoleConfig(BaseModel):
    role: Role
    count: int
    skills: dict[str, Any]

DEFAULT_BOARDS = {
    "预女猎白": {
        "total_players": 12,
        "roles": [
            {"role": Role.WEREWOLF, "count": 4},
            {"role": Role.SEER, "count": 1},
            {"role": Role.WITCH, "count": 1},
            {"role": Role.HUNTER, "count": 1},
            {"role": Role.IDIOT, "count": 1},
            {"role": Role.VILLAGER, "count": 4},
        ]
    },
    "预女猎守": {
        "total_players": 12,
        "roles": [
            {"role": Role.WEREWOLF, "count": 4},
            {"role": Role.SEER, "count": 1},
            {"role": Role.WITCH, "count": 1},
            {"role": Role.HUNTER, "count": 1},
            {"role": Role.GUARDIAN, "count": 1},
            {"role": Role.VILLAGER, "count": 4},
        ]
    }
}

ROLE_SKILLS = {
    Role.WITCH: {
        "save_potions": 1,
        "poison_potions": 1,
        "can_save_self": False,
    },
    Role.GUARDIAN: {
        "cannot_protect_same": True,
    },
    Role.HUNTER: {
        "shoot_on_death_by_knife": True,
        "shoot_on_death_by_poison": True,
        "cannot_shoot_on_vote": True,
    }
}
```

### 10. MessageBus 协议

**MessageType 枚举：**
```python
class MessageType(Enum):
    PUBLIC_SPEAK = "public"
    WOLF_CHANNEL = "wolf_channel"
    PRIVATE = "private"
    SYSTEM = "system"
    LAST_WORDS = "last_words"
```

**消息格式：**
```python
class Message(BaseModel):
    type: MessageType
    sender_id: str | None = None
    receiver_id: str | None = None
    content: str
    timestamp: datetime
    phase: str
    round: int
```

**狼队频道限制：**
- 仅夜间阶段开放
- 仅狼人玩家可发送/接收
- 内容不记录到公开日志（仅记录"狼队频道发言"事件，不记录内容）
- 用于战术协商：刀谁、焊跳安排、悍跳策略

**发言顺序：**
- 警长决定死左死右
- 顺时针/逆时针发言
- PK 阶段由 PK 玩家先行发言

### 11. AgentMemory 存储结构

```python
class ShortTermMemory(BaseModel):
    """短时记忆：单局事件流"""
    game_id: str
    events: list[GameEvent] = []
    beliefs: dict[str, float] = {}  # 玩家ID -> 身份概率

    def add_event(self, event: GameEvent): ...
    def query(self, player_id: str) -> list[GameEvent]: ...

class LongTermMemory(BaseModel):
    """长时记忆：跨对局行为模式"""
    player_profiles: dict[str, PlayerProfile] = {}

class PlayerProfile(BaseModel):
    player_id: str
    total_games: int = 0
    win_rate: float = 0.0
    role_histories: dict[str, int] = {}
    typical_vote_pattern: str | None = None
    speaking_style: str | None = None

class AgentMemory:
    short_term: ShortTermMemory
    long_term: LongTermMemory

    async def add_event(self, event: GameEvent): ...
    async def get_recent_events(self, count: int) -> list[GameEvent]: ...
    async def update_belief(self, player_id: str, probability: float): ...
    async def summarize_for_prompt(self) -> str: ...
```

### 12. LLM Prompts 模板结构

```python
# llm/prompts.py

ROLE_SYSTEM_PROMPTS = {
    Role.WEREWOLF: """你是狼人。你需要：
1. 伪装成好人，引导好人错误决策
2. 在狼队频道与同伴协调刀人目标
3. 分析场上形式，找出神职身份
4. 悍跳预言家或隐藏身份策略性发言

你的目标是让狼人存活到最后。""",

    Role.SEER: """你是预言家。你的技能是每晚查验一人是好是坏。
1. 查验结果只有你自己知道
2. 白天需要想办法报验人信息
3. 保护自己不要被抗推
4. 分析谁是狼人

你的目标是带领好人获胜。""",

    Role.WITCH: """你是女巫。你有一瓶解药和一瓶毒药。
1. 解药可以救人（首夜自救可配置）
2. 毒药可以杀人
3. 根据形式决定用药时机
4. 尽量隐藏身份

你的目标是带领好人获胜。""",

    Role.HUNTER: """你是猎人。你死亡时可以开枪带走一人。
1. 被刀或被毒时可以开枪
2. 被票不能开枪
3. 选择开枪目标需要谨慎

你的目标是带领好人获胜。""",

    Role.GUARDIAN: """你是守卫。你每晚可以守护一人。
1. 不能连续守护同一人
2. 守护成功则该夜无人死亡

你的目标是带领好人获胜。""",

    Role.IDIOT: """你是白痴。你被票时可以翻牌豁免放逐。
1. 翻牌后你可以继续发言但不能投票
2. 你的身份在翻牌前需要隐藏

你的目标是带领好人获胜。""",

    Role.VILLAGER: """你是平民。你没有技能。
1. 通过发言和投票找出狼人
2. 分析场上形式判断身份
3. 合理投票

你的目标是带领好人获胜。"""
}

def build_speak_prompt(agent: RoleAgent, context: dict) -> str:
    """生成发言 prompt"""
    return f"""当前情况：
{context['game_state']}

你的身份：{agent.role.value}
你的座位：{agent.player_id}

你的短时记忆：
{await agent.memory.summarize_for_prompt()}

请生成一段符合你身份的发言（100-200字）：
"""

def build_night_action_prompt(agent: RoleAgent, private_info: PrivateInfo) -> str:
    """生成夜间行动 prompt"""
    return f"""夜间行动阶段。
你的身份：{agent.role.value}

私有信息：{private_info}

你的短时记忆：
{await agent.memory.summarize_for_prompt()}

请决定你的行动：
"""
```

### 13. 引擎启动入口

```
运行入口：
1. uv run python -m werewolf → src/werewolf/__main__.py
2. 或直接运行 cli.py（开发调试用）

启动流程：
src/werewolf/__main__.py
  → FastAPI app (app/main.py)
  → GameEngine.start() 开始对局
  → 循环驱动阶段流转
```

**__main__.py 示例：**
```python
# src/werewolf/__main__.py
from app.engine.game import GameEngine

async def main():
    engine = GameEngine()
    await engine.start()

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
```

## 游戏规则（标准狼人杀）

**角色：** 狼人、预言家、女巫、猎人、平民

**阶段：**
- 黑夜：狼人杀人、预言家查验、女巫用药（救/毒）
- 白天：讨论 → 投票 → 放逐
- 特殊：猎人死亡开枪，女巫药水有限

**胜负条件：**
- 好人胜利：所有狼人出局
- 狼人胜利：狼人数量等于好人数量（屠边）或全部神/民出局

## 技术栈

- Python 3.12+
- FastAPI、Uvicorn、Pydantic 2、WebSockets
- OpenAI SDK / Claude API（LLM驱动的 Agent）
- httpx（外部调用）
- pytest、pytest-asyncio（测试）
- black、ruff（代码检查）
