# AI 狼人杀 — 多智能体协作与博弈系统

多智能体系统，AI Agent 分别扮演狼人、预言家、女巫、猎人、平民等不同角色，在严格的信息不对称约束下独立进行推理、发言与决策。

## 快速启动

### 1. 后端启动

```bash
# 进入项目目录
cd /Users/xiaoluo/Desktop/claude/week16/werewolf

# 方式一：运行游戏（命令行模式）
python -m src.werewolf

# 方式二：启动 API 服务器（支持 WebSocket）
uv run uvicorn app.main:app --reload --port 8000
```

### 2. 前端启动

```bash
# 进入前端目录
cd frontend

# 安装依赖
npm install

# 开发模式
npm run dev

# 生产构建
npm run build
```

### 3. 访问

- 前端页面：http://localhost:3000
- 后端 API：http://localhost:8000
- WebSocket：ws://localhost:8000/ws/game/{game_id}

## 项目结构

```
werewolf/
├── app/                    # 后端应用
│   ├── main.py            # FastAPI 入口
│   ├── config.py          # 板子配置
│   ├── engine/            # 对局引擎
│   ├── models/            # 数据模型
│   ├── agents/            # 多智能体框架
│   ├── llm/                # LLM 集成
│   ├── communication/      # 通信机制
│   └── logs/              # 结构化日志
├── src/werewolf/          # 入口包
└── frontend/              # 前端应用
    ├── src/
    │   ├── components/    # React 组件
    │   ├── stores/        # 状态管理
    │   └── hooks/         # WebSocket 等
    └── package.json
```

## 功能模式

1. **纯 AI 对战** — 所有角色由 AI 控制，观战者实时观看
2. **人机混战** — 人类选择一个或多个角色参与对局
3. **对局回放** — 加载历史日志，按时间轴回放完整过程

## 技术栈

- 后端：Python 3.12+ / FastAPI / Pydantic 2 / WebSockets
- 前端：React 18 / TypeScript / Tailwind CSS / Zustand
- LLM：OpenAI API / Claude API（可配置）