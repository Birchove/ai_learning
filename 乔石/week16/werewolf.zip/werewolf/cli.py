import asyncio

from app.engine.game import Game


async def main():
    print("Game started")
    game = Game()
    await game.start()


if __name__ == "__main__":
    asyncio.run(main())
