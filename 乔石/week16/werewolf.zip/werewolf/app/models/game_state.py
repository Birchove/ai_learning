from typing import Optional

from pydantic import BaseModel

from app.models.player import (
    DeathRecord,
    NightAction,
    PlayerState,
    VoteRecord,
)


class GameState(BaseModel):
    game_id: str
    players: list[PlayerState]
    current_phase: str  # Phase value
    day_number: int = 1
    night_actions: dict[str, list[NightAction]] = {}  # 每夜的动作记录
    vote_records: list[VoteRecord] = []  # 投票记录
    death_records: list[DeathRecord] = []  # 死亡记录
    sheriff_id: Optional[str] = None
    eliminated_player: Optional[str] = None  # 本轮放逐的人
    last_words_players: list[str] = []  # 有遗言权的玩家
    # 胜负
    winner: Optional[str] = None  # village/werewolf
    is_game_over: bool = False

    def get_alive_players(self) -> list[PlayerState]:
        return [p for p in self.players if p.is_alive]

    def get_player(self, player_id: str) -> Optional[PlayerState]:
        for p in self.players:
            if p.player_id == player_id:
                return p
        return None

    def get_players_by_role(self, role: str) -> list[PlayerState]:
        return [p for p in self.players if p.role == role and p.is_alive]

    def kill_player(self, player_id: str) -> None:
        player = self.get_player(player_id)
        if player:
            player.is_alive = False

    def is_werewolf_alive(self) -> bool:
        return any(p.role == "werewolf" and p.is_alive for p in self.players)

    def werewolf_count(self) -> int:
        return sum(1 for p in self.players if p.role == "werewolf" and p.is_alive)

    def good_count(self) -> int:
        return sum(1 for p in self.players if p.role != "werewolf" and p.is_alive)