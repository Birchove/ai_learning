from enum import Enum


class Role(Enum):
    WEREWOLF = "werewolf"
    SEER = "seer"
    WITCH = "witch"
    HUNTER = "hunter"
    GUARDIAN = "guardian"
    IDIOT = "idiot"
    VILLAGER = "villager"


class ActionType(Enum):
    KILL = "kill"  # 狼人刀人
    CHECK = "check"  # 预言家查验
    SAVE = "save"  # 女巫救人
    POISON = "poison"  # 女巫毒人
    PROTECT = "protect"  # 守卫守护
    SHOOT = "shoot"  # 猎人开枪
    VOTE = "vote"  # 投票放逐
    SPEAK = "speak"  # 发言
    SHERIFF_ELECT = "sheriff_elect"  # 警长竞选


class Phase(Enum):
    NIGHT = "night"
    DAY = "day"
    SPEAK = "speak"  # 白天发言阶段
    VOTE = "vote"  # 投票阶段
    LAST_WORDS = "last_words"  # 遗言阶段
    RESULT = "result"  # 结算阶段
    GAME_OVER = "game_over"


class MessageType(Enum):
    PUBLIC_SPEAK = "public"  # 公屏发言（白天讨论）
    WOLF_CHANNEL = "wolf_channel"  # 狼队频道（仅狼人夜间）
    PRIVATE = "private"  # 私聊（预留）
    SYSTEM = "system"  # 系统消息（死亡公告等）
    LAST_WORDS = "last_words"  # 遗言