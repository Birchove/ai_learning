from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel

from app.models.role import ActionType


class PlayerState(BaseModel):
    player_id: str
    name: str
    role: str  # Role value as string for flexibility
    is_alive: bool = True
    is_sheriff: bool = False
    # 角色技能状态
    witch_has_save: bool = True  # 解药
    witch_has_poison: bool = True  # 毒药
    guardian_last_protect: Optional[str] = None  # 昨晚守的人ID
    hunter_can_shoot: bool = True
    idiot_revealed: bool = False  # 白痴是否已翻牌
    voted_for: Optional[str] = None  # 本轮投票投了谁


class VoteRecord(BaseModel):
    day_number: int
    round: int
    voter_id: str
    target_id: Optional[str]  # None = 弃票
    is_pk: bool = False


class DeathRecord(BaseModel):
    player_id: str
    day_number: int
    reason: Literal["kill", "vote", "poison", "shoot"]  # 刀/票/毒/枪
    is_revealed: bool = True
    has_last_words: bool = True


class NightAction(BaseModel):
    player_id: str  # 动作者
    action_type: ActionType
    target_id: Optional[str] = None  # 目标玩家（查验/刀人/守人）
    result: Optional[str] = None  # 动作结果（good/bad/saved/blocked等）


class Message(BaseModel):
    type: str  # MessageType value
    sender_id: Optional[str] = None  # None = 系统
    receiver_id: Optional[str] = None  # private 时使用
    content: str
    timestamp: datetime
    phase: str
    round: int = 0


class GameEvent(BaseModel):
    type: str  # phase_start/phase_end/speech/vote/death/reveal
    data: dict
    timestamp: datetime


class PrivateInfo(BaseModel):
    my_role: str  # Role value
    my_player_id: str

    # 预言家
    check_result: Optional[str] = None  # "good" or "bad"

    # 女巫
    kill_target: Optional[str] = None  # 当晚刀谁（首夜不知）
    witch_save_remaining: bool = True
    witch_poison_remaining: bool = True

    # 守卫
    guardian_last_protect: Optional[str] = None  # 昨晚守的人（不能连守）
    guardian_cannot_protect: Optional[str] = None  # 等于 last_protect

    # 狼人
    wolf_teammates: list[str] = []
    last_kill_target: Optional[str] = None

    # 猎人与白痴
    hunter_can_shoot: bool = True
    hunter_death_reason: Optional[str] = None  # 被刀/被票，用于判断能否开枪
    idiot_revealed: bool = False