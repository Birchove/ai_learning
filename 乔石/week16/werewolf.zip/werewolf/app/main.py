from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
import uuid

from app.api.game_api import router as game_router
from app.api.spectator import router as spectator_router
from app.engine.game_manager import game_manager
from app.engine.game import GameEngine

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "werewolf"}


# 注册路由
app.include_router(game_router, prefix="/api", tags=["game"])
app.include_router(spectator_router, prefix="/api", tags=["spectator"])


# WebSocket 连接管理器（复用 GameManager）
@app.websocket("/ws/game/{game_id}")
async def websocket_game(websocket: WebSocket, game_id: str):
    """游戏实时 WebSocket"""
    await game_manager.connect(websocket, game_id)
    try:
        while True:
            data = await websocket.receive_text()
    except WebSocketDisconnect:
        game_manager.disconnect(websocket, game_id)


@app.websocket("/ws/spectator/{game_id}")
async def websocket_spectator(websocket: WebSocket, game_id: str):
    """观战 WebSocket"""
    await game_manager.connect(websocket, game_id)
    try:
        while True:
            data = await websocket.receive_text()
    except WebSocketDisconnect:
        game_manager.disconnect(websocket, game_id)


@app.get("/ws/games")
async def list_games():
    """列出当前游戏"""
    return {"games": list(game_manager.connections.keys())}


@app.post("/api/games/{game_id}/start")
async def start_game(game_id: str):
    """启动游戏并开始广播事件"""
    # 检查游戏是否已存在
    existing_game = game_manager.get_game(game_id)
    if existing_game:
        return {"game_id": game_id, "status": "already_running"}

    # 创建并启动游戏（异步，不阻塞）
    async def run_game():
        engine = GameEngine(game_id)
        await engine.start()

    # 后台运行游戏
    import asyncio
    asyncio.create_task(run_game())

    return {"game_id": game_id, "status": "started"}


@app.post("/api/games")
async def create_game():
    """创建新游戏"""
    game_id = str(uuid.uuid4())
    game_manager.create_game(game_id)
    return {"game_id": game_id, "status": "created"}