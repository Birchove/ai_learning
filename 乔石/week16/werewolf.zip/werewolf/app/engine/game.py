import asyncio
import uuid
from datetime import datetime
from typing import Optional

from app.config import BoardConfig, DEFAULT_BOARDS
from app.models import (
    ActionType,
    GameState,
    NightAction,
    Phase,
    PlayerState,
    PrivateInfo,
    VoteRecord,
)
from app.engine.judge import Judge
from app.engine.phase import PhaseHandler
from app.engine.game_manager import GameManager


class GameEngine:
    """对局引擎 - 驱动游戏主循环"""

    def __init__(self, game_id: str, board_name: str = "预女猎白"):
        self.game_id = game_id
        self.board_config: BoardConfig = DEFAULT_BOARDS.get(board_name, DEFAULT_BOARDS["预女猎白"])
        self.game_state: Optional[GameState] = None
        self.judge: Optional[Judge] = None
        self.phase_handler: Optional[PhaseHandler] = None
        self.agents: dict[str, object] = {}  # player_id -> agent
        self.game_manager = GameManager.get_instance()
        self.running_game = self.game_manager.create_game(game_id)

    async def emit(self, event: dict) -> None:
        """发射事件到观战者"""
        await self.running_game.emit(event)

    async def start(self) -> GameState:
        """开始游戏"""
        # 发送游戏开始事件
        await self.emit({"type": "phase", "phase": "night", "day": 1})
        await self.emit({"type": "connect", "game_id": self.game_id})

        print("游戏开始")

        # 初始化游戏状态
        self.game_state = await self._setup_game()

        if not self.game_state:
            raise RuntimeError("游戏初始化失败")

        self.judge = Judge(self.game_state)
        self.phase_handler = PhaseHandler(self.game_state)

        # 发送玩家列表
        await self.emit({
            "type": "players",
            "players": [
                {"player_id": p.player_id, "name": p.name, "role": p.role, "is_alive": p.is_alive}
                for p in self.game_state.players
            ]
        })

        # 游戏主循环
        while not self.game_state.is_game_over:
            # 黑夜阶段
            await self._night_phase()

            # 检查胜负
            is_over, winner = self.judge.check_win_condition()
            if is_over:
                self.game_state.is_game_over = True
                self.game_state.winner = winner
                await self.emit({
                    "type": "game_end",
                    "winner": winner,
                    "survivors": [p.player_id for p in self.game_state.players if p.is_alive]
                })
                break

            # 白天阶段
            await self._day_phase()

            # 再次检查胜负
            is_over, winner = self.judge.check_win_condition()
            if is_over:
                self.game_state.is_game_over = True
                self.game_state.winner = winner
                await self.emit({
                    "type": "game_end",
                    "winner": winner,
                    "survivors": [p.player_id for p in self.game_state.players if p.is_alive]
                })
                break

        print(f"游戏结束，胜利方: {self.game_state.winner}")
        return self.game_state

    async def _setup_game(self) -> GameState:
        """初始化游戏"""
        players = []

        # 分配角色
        role_list: list[str] = []
        for role_config in self.board_config.roles:
            role_list.extend([role_config.role] * role_config.count)

        # 如果角色不够，填充平民
        while len(role_list) < self.board_config.total_players:
            role_list.append("villager")

        # 随机分配给玩家
        import random

        random.shuffle(role_list)

        for i in range(self.board_config.total_players):
            players.append(
                PlayerState(
                    player_id=f"player_{i + 1}",
                    name=f"玩家{i + 1}",
                    role=role_list[i],
                )
            )

        return GameState(
            game_id=self.game_id,
            players=players,
            current_phase=Phase.NIGHT.value,
            day_number=1,
        )

    async def _night_phase(self) -> None:
        """黑夜阶段"""
        print(f"\n=== 第 {self.game_state.day_number} 天 黑夜 ===")
        await self.emit({"type": "phase", "phase": "night", "day": self.game_state.day_number})

        await self.phase_handler.handle_night_start()

        # 收集各角色的夜间动作
        night_actions: dict[str, list[NightAction]] = {}

        for player in self.game_state.players:
            if not player.is_alive:
                continue

            private_info = self.phase_handler.build_private_info(player)

            # 模拟各角色夜间行动
            action = await self._get_night_action(player, private_info)
            if action:
                if player.player_id not in night_actions:
                    night_actions[player.player_id] = []
                night_actions[player.player_id].append(action)

                # 广播夜间动作
                await self.emit({
                    "type": "night_action",
                    "player_id": player.player_id,
                    "role": player.role,
                    "action": action.action_type.value,
                    "target": action.target_id,
                })

        # 解析夜间动作
        prev_guardian_target = None
        for p in self.game_state.players:
            if p.role == "guardian":
                prev_guardian_target = p.guardian_last_protect
                break

        deaths, guarded_player, action_results = self.judge.resolve_night(
            night_actions, prev_guardian_target
        )

        print(f"夜间动作结果: {action_results}")
        print(f"死亡: {[d.player_id for d in deaths]}")

        # 处理死亡
        for death in deaths:
            player = self.game_state.get_player(death.player_id)
            if player:
                player.is_alive = False
                await self.emit({
                    "type": "death",
                    "player_id": death.player_id,
                    "role": player.role,  # 死亡后揭示身份
                    "reason": death.reason,
                    "day": self.game_state.day_number,
                    "has_last_words": death.has_last_words,
                })

        # 更新守卫上次守护目标
        if guarded_player:
            for p in self.game_state.players:
                if p.role == "guardian":
                    p.guardian_last_protect = guarded_player

        # 更新女巫药水状态
        for player in self.game_state.players:
            if player.role == "witch":
                for actions in night_actions.values():
                    for action in actions:
                        if action.action_type == ActionType.SAVE:
                            player.witch_has_save = False
                        if action.action_type == ActionType.POISON:
                            player.witch_has_poison = False

    async def _get_night_action(
        self, player: PlayerState, private_info: PrivateInfo
    ) -> Optional[NightAction]:
        """获取玩家夜间动作"""
        if player.role == "werewolf":
            alive_players = [p for p in self.game_state.players if p.is_alive and p.player_id != player.player_id]
            if alive_players:
                import random
                target = random.choice(alive_players)
                return NightAction(
                    player_id=player.player_id,
                    action_type=ActionType.KILL,
                    target_id=target.player_id,
                )

        elif player.role == "seer":
            alive_players = [p for p in self.game_state.players if p.is_alive and p.player_id != player.player_id]
            if alive_players:
                import random
                target = random.choice(alive_players)
                return NightAction(
                    player_id=player.player_id,
                    action_type=ActionType.CHECK,
                    target_id=target.player_id,
                )

        elif player.role == "guardian":
            candidates = [
                p for p in self.game_state.players
                if p.is_alive and p.player_id != private_info.guardian_cannot_protect
            ]
            if candidates:
                import random
                target = random.choice(candidates)
                return NightAction(
                    player_id=player.player_id,
                    action_type=ActionType.PROTECT,
                    target_id=target.player_id,
                )

        return None

    async def _day_phase(self) -> None:
        """白天阶段"""
        print(f"\n=== 第 {self.game_state.day_number} 天 白天 ===")
        await self.emit({"type": "phase", "phase": "day", "day": self.game_state.day_number})

        await self.phase_handler.handle_day_start([])

        # 发言阶段（简化）
        await self.emit({"type": "phase", "phase": "speak", "day": self.game_state.day_number})

        # 模拟发言
        for i, player in enumerate(self.game_state.get_alive_players()[:3]):  # 只模拟前3人发言
            speeches = [
                "我觉得这个人不太对劲",
                "我是好人，大家可以相信我",
                "这一轮我觉得应该投他",
            ]
            await self.emit({
                "type": "speech",
                "player_id": player.player_id,
                "text": speeches[i % len(speeches)],
                "seq": i + 1,
                "role": player.role,
            })
            await asyncio.sleep(0.1)  # 模拟发言间隔

        # 投票阶段
        await self.emit({"type": "phase", "phase": "vote", "day": self.game_state.day_number})

        vote_records: list[VoteRecord] = []
        alive_players = self.game_state.get_alive_players()

        for player in alive_players:
            import random
            targets = [p.player_id for p in alive_players if p.player_id != player.player_id]
            targets.append(None)

            target_id = random.choice(targets)
            vote = VoteRecord(
                day_number=self.game_state.day_number,
                round=1,
                voter_id=player.player_id,
                target_id=target_id,
            )
            vote_records.append(vote)

            await self.emit({
                "type": "vote",
                "player_id": player.player_id,
                "target": target_id,
                "day": self.game_state.day_number,
                "round": 1,
            })

        self.game_state.vote_records.extend(vote_records)

        # 解析投票结果
        eliminated, is_pk = self.judge.resolve_vote(vote_records)

        if eliminated:
            print(f"放逐玩家: {eliminated}")
            player = self.game_state.get_player(eliminated)
            if player:
                player.is_alive = False
                await self.emit({
                    "type": "death",
                    "player_id": eliminated,
                    "role": player.role,
                    "reason": "vote",
                    "day": self.game_state.day_number,
                    "has_last_words": True,
                })
        elif is_pk:
            print("平票，进入 PK 阶段（简化处理）")
            import random
            pk_targets = [r.target_id for r in vote_records if r.target_id]
            if pk_targets:
                eliminated = random.choice(pk_targets)
                player = self.game_state.get_player(eliminated)
                if player:
                    player.is_alive = False
                    await self.emit({
                        "type": "death",
                        "player_id": eliminated,
                        "role": player.role,
                        "reason": "vote",
                        "day": self.game_state.day_number,
                        "has_last_words": True,
                    })

        self.game_state.day_number += 1
        print(f"存活玩家: {[p.player_id for p in self.game_state.players if p.is_alive]}")