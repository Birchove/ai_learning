"""游戏管理器 - 管理所有游戏实例和 WebSocket 广播"""
import asyncio
import uuid
from typing import Optional

from fastapi import WebSocket


class GameManager:
    """游戏管理器 - 单例模式"""

    _instance: Optional['GameManager'] = None

    def __init__(self):
        self.games: dict[str, 'RunningGame'] = {}  # game_id -> RunningGame
        self.connections: dict[str, list[WebSocket]] = {}  # game_id -> WebSocket list

    @classmethod
    def get_instance(cls) -> 'GameManager':
        if cls._instance is None:
            cls._instance = GameManager()
        return cls._instance

    def create_game(self, game_id: str) -> 'RunningGame':
        """创建新游戏"""
        game = RunningGame(game_id, self)
        self.games[game_id] = game
        self.connections[game_id] = []
        return game

    def get_game(self, game_id: str) -> Optional['RunningGame']:
        """获取游戏"""
        return self.games.get(game_id)

    async def connect(self, websocket: WebSocket, game_id: str) -> None:
        """WebSocket 连接"""
        await websocket.accept()
        if game_id not in self.connections:
            self.connections[game_id] = []
        self.connections[game_id].append(websocket)
        # 发送连接成功事件
        await self.broadcast(game_id, {"type": "connect", "game_id": game_id})

    def disconnect(self, websocket: WebSocket, game_id: str) -> None:
        """WebSocket 断开"""
        if game_id in self.connections:
            if websocket in self.connections[game_id]:
                self.connections[game_id].remove(websocket)

    async def broadcast(self, game_id: str, message: dict) -> None:
        """广播消息到所有连接"""
        if game_id not in self.connections:
            return

        disconnected = []
        for ws in self.connections[game_id]:
            try:
                await ws.send_json(message)
            except Exception:
                disconnected.append(ws)

        # 清理断开的连接
        for ws in disconnected:
            self.disconnect(ws, game_id)

    async def send_to_player(self, player_id: str, message: dict) -> None:
        """发送消息到特定玩家（需要遍历找到对应连接）"""
        # 简化实现：广播给所有
        pass


class RunningGame:
    """运行中的游戏"""

    def __init__(self, game_id: str, manager: GameManager):
        self.game_id = game_id
        self.manager = manager
        self.events: list[dict] = []

    async def emit(self, event: dict) -> None:
        """发射事件到所有观战者"""
        self.events.append(event)
        await self.manager.broadcast(self.game_id, event)

    def get_events(self) -> list[dict]:
        """获取所有事件"""
        return self.events


# 全局实例
game_manager = GameManager.get_instance()