from datetime import datetime
from typing import Optional

from app.models import (
    ActionType,
    DeathRecord,
    GameState,
    NightAction,
    Phase,
    PlayerState,
    VoteRecord,
)


class Judge:
    """裁决夜间动作、投票结果、胜负条件"""

    def __init__(self, game_state: GameState):
        self.game_state = game_state

    def resolve_night(
        self,
        night_actions: dict[str, NightAction],
        prev_guardian_target: Optional[str] = None,
    ) -> tuple[list[DeathRecord], Optional[str], dict[str, str]]:
        """
        解析夜间动作并返回死亡结果

        Returns:
            deaths: 死亡记录列表
            guarded_player: 被守卫保护的人（如果有）
            action_results: 各角色动作结果 {"player_id": "result"}
        """
        deaths: list[DeathRecord] = []
        action_results: dict[str, str] = {}

        # 1. 获取守卫守护目标（如果有的话）
        guardian_target: Optional[str] = None
        for player_id, actions in night_actions.items():
            for action in actions:
                if action.action_type == ActionType.PROTECT and action.target_id:
                    guardian_target = action.target_id
                    action_results[player_id] = f"protecting_{guardian_target}"

        # 2. 获取狼人刀人目标
        kill_target: Optional[str] = None
        for player_id, actions in night_actions.items():
            player = self.game_state.get_player(player_id)
            if player and player.role == "werewolf":
                for action in actions:
                    if action.action_type == ActionType.KILL and action.target_id:
                        kill_target = action.target_id

        # 3. 获取女巫救人/毒人
        witch_save_target: Optional[str] = None
        witch_poison_target: Optional[str] = None
        for player_id, actions in night_actions.items():
            player = self.game_state.get_player(player_id)
            if player and player.role == "witch":
                for action in actions:
                    if action.action_type == ActionType.SAVE and action.target_id:
                        witch_save_target = action.target_id
                        action_results[player_id] = "saved"
                    if action.action_type == ActionType.POISON and action.target_id:
                        witch_poison_target = action.target_id
                        action_results[player_id] = f"poisoned_{witch_poison_target}"

        # 4. 获取预言家查验结果
        for player_id, actions in night_actions.items():
            player = self.game_state.get_player(player_id)
            if player and player.role == "seer":
                for action in actions:
                    if action.action_type == ActionType.CHECK and action.target_id:
                        # 记录查验结果
                        target = self.game_state.get_player(action.target_id)
                        if target:
                            action_results[player_id] = (
                                "good" if target.role != "werewolf" else "bad"
                            )

        # 5. 死亡结算
        # 检查守卫是否守中
        is_guarded = kill_target and guardian_target == kill_target

        # 检查女巫是否救人（守中优先于女巫救人）
        is_saved = witch_save_target == kill_target if kill_target else False

        # 狼人刀人导致死亡
        if kill_target and not is_guarded and not is_saved:
            player = self.game_state.get_player(kill_target)
            if player and player.is_alive:
                deaths.append(
                    DeathRecord(
                        player_id=kill_target,
                        day_number=self.game_state.day_number,
                        reason="kill",
                        is_revealed=True,
                        has_last_words=True,
                    )
                )

        # 女巫毒人导致死亡
        if witch_poison_target:
            player = self.game_state.get_player(witch_poison_target)
            if player and player.is_alive:
                # 检查是否已经死亡（狼人刀了）
                if not any(d.player_id == witch_poison_target for d in deaths):
                    deaths.append(
                        DeathRecord(
                            player_id=witch_poison_target,
                            day_number=self.game_state.day_number,
                            reason="poison",
                            is_revealed=True,
                            has_last_words=True,
                        )
                    )

        # 记录被保护的人
        if is_guarded:
            action_results["guardian"] = f"guarded_{guardian_target}"
        if is_saved:
            action_results["witch"] = f"saved_{witch_save_target}"

        return deaths, guardian_target, action_results

    def resolve_vote(self, vote_records: list[VoteRecord]) -> tuple[Optional[str], bool]:
        """
        解析投票结果

        Returns:
            (eliminated_player_id, is_pk) - 被放逐的玩家，是否是 PK
        """
        if not vote_records:
            return None, False

        # 统计票数
        votes: dict[str, int] = {}
        for record in vote_records:
            if record.target_id:
                votes[record.target_id] = votes.get(record.target_id, 0) + 1

        if not votes:
            return None, False

        # 找出最高票
        max_votes = max(votes.values())
        candidates = [p for p, v in votes.items() if v == max_votes]

        if len(candidates) == 1:
            return candidates[0], False
        else:
            # 平票，进入 PK
            return None, True

    def check_win_condition(self) -> tuple[bool, Optional[str]]:
        """
        检查胜负条件

        Returns:
            (is_game_over, winner) - 游戏是否结束，胜利方
        """
        werewolf_alive = self.game_state.werewolf_count()
        good_alive = self.game_state.good_count()

        if werewolf_alive == 0:
            return True, "village"
        if werewolf_alive >= good_alive:
            return True, "werewolf"

        return False, None

    def can_hunter_shoot(self, death_reason: Optional[str]) -> bool:
        """猎人是否可以开枪"""
        if death_reason == "vote":
            return False
        return True