from datetime import datetime
from typing import Optional

from app.models import GameState, Message, Phase, PlayerState, PrivateInfo


class PhaseHandler:
    """处理各阶段的逻辑"""

    def __init__(self, game_state: GameState):
        self.game_state = game_state

    async def handle_night_start(self) -> None:
        """黑夜开始"""
        self.game_state.current_phase = Phase.NIGHT.value
        self.game_state.night_actions = {}

    async def handle_day_start(self, deaths: list[PlayerState]) -> None:
        """白天开始，报告死亡"""
        self.game_state.current_phase = Phase.DAY.value
        # 处理死亡玩家
        for player in deaths:
            player.is_alive = False

    async def handle_speak_phase(self) -> None:
        """发言阶段"""
        self.game_state.current_phase = Phase.SPEAK.value

    async def handle_vote_phase(self) -> None:
        """投票阶段"""
        self.game_state.current_phase = Phase.VOTE.value

    def build_private_info(self, player: PlayerState) -> PrivateInfo:
        """根据玩家角色构建私有信息"""
        private_info = PrivateInfo(my_role=player.role, my_player_id=player.player_id)

        if player.role == "seer":
            # 预言家需要在夜间收到查验结果
            pass

        if player.role == "witch":
            private_info.witch_save_remaining = player.witch_has_save
            private_info.witch_poison_remaining = player.witch_has_poison

        if player.role == "guardian":
            private_info.guardian_last_protect = player.guardian_last_protect
            private_info.guardian_cannot_protect = player.guardian_last_protect

        if player.role == "werewolf":
            # 获取狼人同伴
            wolf_teammates = [
                p.player_id
                for p in self.game_state.players
                if p.role == "werewolf" and p.player_id != player.player_id and p.is_alive
            ]
            private_info.wolf_teammates = wolf_teammates

        if player.role == "hunter":
            private_info.hunter_can_shoot = player.hunter_can_shoot

        if player.role == "idiot":
            private_info.idiot_revealed = player.idiot_revealed

        return private_info

    def get_public_state(self, player: PlayerState) -> dict:
        """获取玩家可见的公开状态"""
        return {
            "game_id": self.game_state.game_id,
            "day_number": self.game_state.day_number,
            "phase": self.game_state.current_phase,
            "alive_players": [
                {"player_id": p.player_id, "name": p.name}
                for p in self.game_state.players
                if p.is_alive
            ],
            "dead_players": [
                {"player_id": p.player_id, "name": p.name, "role": p.role}
                for p in self.game_state.players
                if not p.is_alive
            ],
            "my_player_id": player.player_id,
            "sheriff_id": self.game_state.sheriff_id,
        }