import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from app.models import GameEvent


class GameLogger:
    """游戏日志 - JSON Lines 格式"""

    def __init__(self, log_dir: str = "logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        self.current_game_id: Optional[str] = None
        self.log_file: Optional[Path] = None

    def start_game(self, game_id: str) -> None:
        """开始新的游戏日志"""
        self.current_game_id = game_id
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = self.log_dir / f"game_{game_id}_{timestamp}.jsonl"

    def log_event(self, event: GameEvent) -> None:
        """记录事件"""
        if not self.log_file:
            return

        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(event.model_dump_json() + "\n")

    def log_phase(self, phase: str, day_number: int, start: datetime) -> None:
        """记录阶段开始"""
        event = GameEvent(
            type="phase_start",
            data={"phase": phase, "day_number": day_number, "start": start.isoformat()},
            timestamp=start,
        )
        self.log_event(event)

    def log_night_action(
        self, player_id: str, role: str, action: str, target_id: Optional[str] = None, result: Optional[str] = None
    ) -> None:
        """记录夜间动作"""
        event = GameEvent(
            type="night_action",
            data={
                "player_id": player_id,
                "role": role,
                "action": action,
                "target_id": target_id,
                "result": result,
            },
            timestamp=datetime.now(),
        )
        self.log_event(event)

    def log_speech(self, player_id: str, text: str, seq: int) -> None:
        """记录发言"""
        event = GameEvent(
            type="speech",
            data={"player_id": player_id, "text": text, "seq": seq},
            timestamp=datetime.now(),
        )
        self.log_event(event)

    def log_vote(self, player_id: str, target_id: Optional[str]) -> None:
        """记录投票"""
        event = GameEvent(
            type="vote",
            data={"player_id": player_id, "target_id": target_id},
            timestamp=datetime.now(),
        )
        self.log_event(event)

    def log_elimination(self, player_id: str, reason: str, has_last_words: bool) -> None:
        """记录放逐"""
        event = GameEvent(
            type="elimination",
            data={"player_id": player_id, "reason": reason, "has_last_words": has_last_words},
            timestamp=datetime.now(),
        )
        self.log_event(event)

    def log_game_end(self, winner: str, survivors: list[str]) -> None:
        """记录游戏结束"""
        event = GameEvent(
            type="game_end",
            data={"winner": winner, "survivors": survivors},
            timestamp=datetime.now(),
        )
        self.log_event(event)

    def end_game(self) -> None:
        """结束当前游戏日志"""
        self.current_game_id = None
        self.log_file = None


class EventRecorder:
    """事件录制器 - 用于回放"""

    def __init__(self):
        self.events: list[GameEvent] = []

    def record(self, event: GameEvent) -> None:
        """录制事件"""
        self.events.append(event)

    def get_events(self) -> list[GameEvent]:
        """获取所有事件"""
        return self.events

    def get_events_by_type(self, event_type: str) -> list[GameEvent]:
        """按类型获取事件"""
        return [e for e in self.events if e.type == event_type]

    def clear(self) -> None:
        """清空录制"""
        self.events = []

    def export(self, file_path: Path) -> None:
        """导出事件到文件"""
        with open(file_path, "w", encoding="utf-8") as f:
            for event in self.events:
                f.write(event.model_dump_json() + "\n")

    def import_(self, file_path: Path) -> None:
        """从文件导入事件"""
        self.events = []
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    self.events.append(GameEvent.model_validate_json(line))