"""Logger module - re-export from game_logger for backwards compatibility."""
from app.logs.game_logger import EventRecorder, GameLogger

StructuredLogger = GameLogger

__all__ = ["GameLogger", "EventRecorder", "StructuredLogger"]