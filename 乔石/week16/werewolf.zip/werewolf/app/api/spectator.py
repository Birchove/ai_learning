from fastapi import APIRouter

router = APIRouter()


@router.get("/spectator/{game_id}")
async def spectator_game(game_id: str) -> dict:
    """观战接口 - 获取游戏观战信息"""
    return {
        "game_id": game_id,
        "status": "spectating",
        "can_join": False,
    }


@router.get("/spectator/{game_id}/stream")
async def spectator_stream(game_id: str) -> dict:
    """观战流 - 通过 SSE 或 WebSocket 提供实时观战"""
    return {"message": "Use WebSocket for real-time streaming"}