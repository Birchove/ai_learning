from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.models import GameState

router = APIRouter()


class GameCreateRequest(BaseModel):
    board_name: str = "预女猎白"


class GameResponse(BaseModel):
    game_id: str
    status: str


@router.post("/games", response_model=GameResponse)
async def create_game(request: GameCreateRequest) -> GameResponse:
    """创建新游戏"""
    # 实际实现需要调用 GameEngine
    return GameResponse(game_id="demo_game_id", status="created")


@router.get("/games/{game_id}", response_model=dict)
async def get_game(game_id: str) -> dict:
    """获取游戏状态"""
    # 实际实现需要从 GameEngine 获取状态
    return {
        "game_id": game_id,
        "status": "in_progress",
        "players": [],
        "current_phase": "night",
        "day_number": 1,
    }


@router.get("/games/{game_id}/state", response_model=dict)
async def get_game_state(game_id: str) -> dict:
    """获取完整游戏状态"""
    raise HTTPException(status_code=404, detail="Game not found")