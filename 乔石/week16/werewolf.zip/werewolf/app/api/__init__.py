from app.api.game_api import router as game_router
from app.api.spectator import router as spectator_router
from app.api.websocket import game_websocket

__all__ = ["game_router", "spectator_router", "game_websocket"]