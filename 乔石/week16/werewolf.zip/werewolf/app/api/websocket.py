from fastapi import WebSocket, WebSocketDisconnect
from typing import Optional

from app.models import GameState


class GameWebSocket:
    """WebSocket 管理"""

    def __init__(self):
        self.connections: dict[str, list[WebSocket]] = {}  # game_id -> connections

    async def connect(self, websocket: WebSocket, game_id: str) -> None:
        """连接 WebSocket"""
        await websocket.accept()
        if game_id not in self.connections:
            self.connections[game_id] = []
        self.connections[game_id].append(websocket)

    def disconnect(self, websocket: WebSocket, game_id: str) -> None:
        """断开 WebSocket"""
        if game_id in self.connections:
            if websocket in self.connections[game_id]:
                self.connections[game_id].remove(websocket)

    async def broadcast_to_game(self, game_id: str, message: dict) -> None:
        """向游戏房间广播消息"""
        if game_id not in self.connections:
            return

        for connection in self.connections[game_id]:
            try:
                await connection.send_json(message)
            except Exception:
                pass

    async def send_to_player(self, player_id: str, message: dict) -> None:
        """向特定玩家发送消息（需要知道玩家的 game_id）"""
        pass  # 实现需要维护 player_id -> websocket 的映射


game_websocket = GameWebSocket()