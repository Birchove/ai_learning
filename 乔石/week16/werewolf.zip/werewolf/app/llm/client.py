from typing import Optional

import openai


class LLMClient:
    """LLM 客户端封装"""

    def __init__(self, model: str = "gpt-4", api_key: Optional[str] = None):
        self.model = model
        self.client = openai.OpenAI(api_key=api_key)

    async def chat(self, messages: list[dict], temperature: float = 0.7) -> str:
        """发送聊天请求"""
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
        )
        return response.choices[0].message.content

    async def generate_speech(
        self, system_prompt: str, context: str, temperature: float = 0.7
    ) -> str:
        """生成发言"""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": context},
        ]
        return await self.chat(messages, temperature)

    async def decide_action(
        self, system_prompt: str, situation: str, options: list[str], temperature: float = 0.3
    ) -> str:
        """决策动作"""
        options_text = "\n".join(f"{i + 1}. {opt}" for i, opt in enumerate(options))
        messages = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": f"{situation}\n\n请从以下选项中选择:\n{options_text}",
            },
        ]
        return await self.chat(messages, temperature)