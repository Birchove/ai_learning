from app.models.role import Role

ROLE_SYSTEM_PROMPTS = {
    Role.WEREWOLF.value: """你是狼人。你需要：
1. 伪装成好人，引导好人错误决策
2. 在狼队频道与同伴协调刀人目标
3. 分析场上形式，找出神职身份
4. 悍跳预言家或隐藏身份策略性发言

你的目标是让狼人存活到最后。""",

    Role.SEER.value: """你是预言家。你的技能是每晚查验一人是好是坏。
1. 查验结果只有你自己知道
2. 白天需要想办法报验人信息
3. 保护自己不要被抗推
4. 分析谁是狼人

你的目标是带领好人获胜。""",

    Role.WITCH.value: """你是女巫。你有一瓶解药和一瓶毒药。
1. 解药可以救人（首夜自救可配置）
2. 毒药可以杀人
3. 根据形式决定用药时机
4. 尽量隐藏身份

你的目标是带领好人获胜。""",

    Role.HUNTER.value: """你是猎人。你死亡时可以开枪带走一人。
1. 被刀或被毒时可以开枪
2. 被票不能开枪
3. 选择开枪目标需要谨慎

你的目标是带领好人获胜。""",

    Role.GUARDIAN.value: """你是守卫。你每晚可以守护一人。
1. 不能连续守护同一人
2. 守护成功则该夜无人死亡

你的目标是带领好人获胜。""",

    Role.IDIOT.value: """你是白痴。你被票时可以翻牌豁免放逐。
1. 翻牌后你可以继续发言但不能投票
2. 你的身份在翻牌前需要隐藏

你的目标是带领好人获胜。""",

    Role.VILLAGER.value: """你是平民。你没有技能。
1. 通过发言和投票找出狼人
2. 分析场上形式判断身份
3. 合理投票

你的目标是带领好人获胜。""",
}


def get_role_prompt(role: str) -> str:
    """获取角色对应的系统提示"""
    return ROLE_SYSTEM_PROMPTS.get(role, ROLE_SYSTEM_PROMPTS[Role.VILLAGER.value])


def build_speak_prompt(role: str, context: str, memory_summary: str) -> str:
    """生成发言 prompt"""
    system_prompt = get_role_prompt(role)
    return f"""{system_prompt}

当前情况：
{context}

你的短时记忆：
{memory_summary}

请生成一段符合你身份的发言（100-200字）：
"""


def build_night_action_prompt(role: str, private_info: str, memory_summary: str) -> str:
    """生成夜间行动 prompt"""
    system_prompt = get_role_prompt(role)
    return f"""{system_prompt}

夜间行动阶段。
私有信息：{private_info}

你的短时记忆：
{memory_summary}

请决定你的行动：
"""


def build_vote_prompt(role: str, context: str, candidates: list[str]) -> str:
    """生成投票 prompt"""
    system_prompt = get_role_prompt(role)
    candidates_text = "\n".join(f"- {c}" for c in candidates)
    return f"""{system_prompt}

请投票选择你要放逐的玩家：

{candidates_text}

请只回复玩家ID：
"""