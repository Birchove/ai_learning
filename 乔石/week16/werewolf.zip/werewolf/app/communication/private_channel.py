from app.models import PrivateInfo


class PrivateChannel:
    """私有信道 - 严格按角色权限分发夜间私密信息"""

    def __init__(self):
        self.channels: dict[str, PrivateInfo] = {}  # player_id -> PrivateInfo

    def deliver(self, player_id: str, private_info: PrivateInfo) -> None:
        """向玩家分发私有信息"""
        self.channels[player_id] = private_info

    def get(self, player_id: str) -> PrivateInfo:
        """获取玩家的私有信息"""
        return self.channels.get(player_id, PrivateInfo(my_role="", my_player_id=player_id))

    def clear(self) -> None:
        """清空所有私有信息"""
        self.channels = {}

    def build_private_info(
        self,
        player_id: str,
        role: str,
        wolf_teammates: list[str] = None,
        check_result: str = None,
        kill_target: str = None,
        witch_save_remaining: bool = True,
        witch_poison_remaining: bool = True,
        guardian_last_protect: str = None,
        hunter_can_shoot: bool = True,
        hunter_death_reason: str = None,
        idiot_revealed: bool = False,
    ) -> PrivateInfo:
        """构建私有信息"""
        return PrivateInfo(
            my_role=role,
            my_player_id=player_id,
            wolf_teammates=wolf_teammates or [],
            check_result=check_result,
            kill_target=kill_target,
            witch_save_remaining=witch_save_remaining,
            witch_poison_remaining=witch_poison_remaining,
            guardian_last_protect=guardian_last_protect,
            guardian_cannot_protect=guardian_last_protect,
            hunter_can_shoot=hunter_can_shoot,
            hunter_death_reason=hunter_death_reason,
            idiot_revealed=idiot_revealed,
        )