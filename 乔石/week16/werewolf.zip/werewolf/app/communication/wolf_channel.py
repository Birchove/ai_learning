from typing import Optional

from app.models import Message
from app.models.role import MessageType


class WolfChannel:
    """狼队频道 - 仅狼人可用的夜间协商频道"""

    def __init__(self):
        self.messages: list[Message] = []
        self.wolf_player_ids: list[str] = []

    def add_wolf(self, player_id: str) -> None:
        """添加狼人玩家"""
        if player_id not in self.wolf_player_ids:
            self.wolf_player_ids.append(player_id)

    def is_wolf(self, player_id: str) -> bool:
        """检查是否是狼人"""
        return player_id in self.wolf_player_ids

    def send(self, sender_id: str, content: str, phase: str = "night", round: int = 0) -> Optional[Message]:
        """发送狼队消息"""
        if not self.is_wolf(sender_id):
            return None

        message = Message(
            type=MessageType.WOLF_CHANNEL.value,
            sender_id=sender_id,
            content=content,
            timestamp=__import__("datetime").datetime.now(),
            phase=phase,
            round=round,
        )
        self.messages.append(message)
        return message

    def get_messages(self) -> list[Message]:
        """获取所有狼队消息"""
        return self.messages

    def get_messages_for_wolf(self) -> list[Message]:
        """获取狼人可见的狼队消息"""
        return self.messages

    def clear(self) -> None:
        """清空狼队消息"""
        self.messages = []

    def reset(self) -> None:
        """重置狼队频道"""
        self.messages = []
        self.wolf_player_ids = []