from datetime import datetime
from typing import Optional

from app.models import Message, MessageType


class MessageBus:
    """消息总线 - 管理所有 Agent 间的通信"""

    def __init__(self):
        self.messages: list[Message] = []

    def send(
        self,
        msg_type: str,
        content: str,
        sender_id: Optional[str] = None,
        receiver_id: Optional[str] = None,
        phase: str = "night",
        round: int = 0,
    ) -> Message:
        """发送消息"""
        message = Message(
            type=msg_type,
            sender_id=sender_id,
            receiver_id=receiver_id,
            content=content,
            timestamp=datetime.now(),
            phase=phase,
            round=round,
        )
        self.messages.append(message)
        return message

    def broadcast_public(self, sender_id: str, content: str, phase: str, round: int) -> Message:
        """公开广播"""
        return self.send(
            msg_type=MessageType.PUBLIC_SPEAK.value,
            content=content,
            sender_id=sender_id,
            phase=phase,
            round=round,
        )

    def send_to_wolf_channel(self, sender_id: str, content: str, phase: str, round: int) -> Message:
        """发送到狼队频道"""
        return self.send(
            msg_type=MessageType.WOLF_CHANNEL.value,
            content=content,
            sender_id=sender_id,
            phase=phase,
            round=round,
        )

    def send_private(
        self, sender_id: str, receiver_id: str, content: str, phase: str, round: int
    ) -> Message:
        """发送私有消息"""
        return self.send(
            msg_type=MessageType.PRIVATE.value,
            content=content,
            sender_id=sender_id,
            receiver_id=receiver_id,
            phase=phase,
            round=round,
        )

    def send_system(self, content: str, phase: str, round: int = 0) -> Message:
        """发送系统消息"""
        return self.send(
            msg_type=MessageType.SYSTEM.value,
            content=content,
            phase=phase,
            round=round,
        )

    def get_messages_for_player(self, player_id: str, msg_type: Optional[str] = None) -> list[Message]:
        """获取玩家可见的消息"""
        result = []
        for msg in self.messages:
            if msg_type and msg.type != msg_type:
                continue
            if msg.type == MessageType.PUBLIC_SPEAK.value:
                result.append(msg)
            elif msg.type == MessageType.SYSTEM.value:
                result.append(msg)
            elif msg.type == MessageType.WOLF_CHANNEL.value:
                # 只有狼人能看狼队频道
                pass  # 需要知道接收者是否是狼人
            elif msg.type == MessageType.PRIVATE.value:
                if msg.receiver_id == player_id or msg.sender_id == player_id:
                    result.append(msg)
        return result

    def get_recent_messages(self, count: int = 10) -> list[Message]:
        """获取最近的消息"""
        return self.messages[-count:] if self.messages else []

    def clear(self) -> None:
        """清空消息"""
        self.messages = []