from typing import Any

from pydantic import BaseModel

from app.models.role import Role


class RoleConfig(BaseModel):
    role: str  # Role value
    count: int
    skills: dict[str, Any] = {}


class BoardConfig(BaseModel):
    name: str  # "预女猎白", "预女猎守", "自定义"
    total_players: int = 12
    roles: list[RoleConfig] = []


DEFAULT_BOARDS = {
    "预女猎白": BoardConfig(
        name="预女猎白",
        total_players=12,
        roles=[
            RoleConfig(role=Role.WEREWOLF.value, count=4),
            RoleConfig(role=Role.SEER.value, count=1),
            RoleConfig(role=Role.WITCH.value, count=1),
            RoleConfig(role=Role.HUNTER.value, count=1),
            RoleConfig(role=Role.IDIOT.value, count=1),
            RoleConfig(role=Role.VILLAGER.value, count=4),
        ],
    ),
    "预女猎守": BoardConfig(
        name="预女猎守",
        total_players=12,
        roles=[
            RoleConfig(role=Role.WEREWOLF.value, count=4),
            RoleConfig(role=Role.SEER.value, count=1),
            RoleConfig(role=Role.WITCH.value, count=1),
            RoleConfig(role=Role.HUNTER.value, count=1),
            RoleConfig(role=Role.GUARDIAN.value, count=1),
            RoleConfig(role=Role.VILLAGER.value, count=4),
        ],
    ),
}

ROLE_SKILLS = {
    Role.WITCH.value: {
        "save_potions": 1,
        "poison_potions": 1,
        "can_save_self": False,
    },
    Role.GUARDIAN.value: {
        "cannot_protect_same": True,
    },
    Role.HUNTER.value: {
        "shoot_on_death_by_knife": True,
        "shoot_on_death_by_poison": True,
        "cannot_shoot_on_vote": True,
    },
}