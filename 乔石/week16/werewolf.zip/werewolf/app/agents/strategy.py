from typing import Optional


class RoleStrategy:
    """角色策略引擎 - 定义各角色的行为约束和目标"""

    def __init__(self, role: str):
        self.role = role
        self.goal = self._get_goal()
        self.constraints = self._get_constraints()

    def _get_goal(self) -> str:
        goals = {
            "werewolf": "伪装好人并存活到最后",
            "seer": "传递验人信息并带领好人获胜",
            "witch": "用药保护好人并毒杀狼人",
            "hunter": "在死亡时开枪带走狼人",
            "guardian": "守护好人存活",
            "idiot": "隐藏身份并存活",
            "villager": "找出狼人并投票放逐",
        }
        return goals.get(self.role, "帮助好人获胜")

    def _get_constraints(self) -> dict:
        constraints = {
            "werewolf": ["不能暴露狼人身份", "需要与狼队协调"],
            "seer": ["查验结果只能自己知道", "需要想办法报验人"],
            "witch": ["解药救人", "毒药杀人", "尽量隐藏身份"],
            "hunter": ["被刀/被毒可以开枪", "被票不能开枪"],
            "guardian": ["不能连续守护同一人"],
            "idiot": ["被票可以翻牌豁免", "翻牌后不能投票"],
            "villager": ["没有技能", "通过发言判断身份"],
        }
        return constraints.get(self.role, {})

    def get_system_prompt(self) -> str:
        return f"""你是 {self.role}。

目标: {self.goal}
约束: {self.constraints}

你的目标是{"让狼人获胜" if self.role == "werewolf" else "带领好人获胜"}。
"""