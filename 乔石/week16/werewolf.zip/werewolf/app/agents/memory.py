from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class GameEvent(BaseModel):
    """游戏事件"""
    type: str  # phase_start/phase_end/speech/vote/death/reveal
    data: dict
    timestamp: datetime = datetime.now()


class ShortTermMemory(BaseModel):
    """短时记忆：单局事件流"""
    game_id: str
    events: list[GameEvent] = []

    def add_event(self, event: GameEvent) -> None:
        self.events.append(event)

    def query(self, player_id: str) -> list[GameEvent]:
        return [e for e in self.events if e.data.get("player_id") == player_id]

    def get_recent(self, count: int) -> list[GameEvent]:
        return self.events[-count:] if self.events else []


class PlayerProfile(BaseModel):
    """玩家画像"""
    player_id: str
    total_games: int = 0
    win_rate: float = 0.0
    role_histories: dict[str, int] = {}
    typical_vote_pattern: Optional[str] = None
    speaking_style: Optional[str] = None


class LongTermMemory(BaseModel):
    """长时记忆：跨对局行为模式"""
    player_profiles: dict[str, PlayerProfile] = {}

    def get_profile(self, player_id: str) -> Optional[PlayerProfile]:
        return self.player_profiles.get(player_id)

    def update_profile(self, profile: PlayerProfile) -> None:
        self.player_profiles[profile.player_id] = profile


class AgentMemory:
    """Agent 记忆系统"""
    short_term: ShortTermMemory
    long_term: LongTermMemory

    def __init__(self, game_id: str):
        self.short_term = ShortTermMemory(game_id=game_id)
        self.long_term = LongTermMemory()

    async def add_event(self, event: GameEvent) -> None:
        self.short_term.add_event(event)

    async def get_recent_events(self, count: int) -> list[GameEvent]:
        return self.short_term.get_recent(count)

    async def update_belief(self, player_id: str, probability: float) -> None:
        pass  # 简化实现

    async def summarize_for_prompt(self) -> str:
        """生成可用于 prompt 的摘要"""
        recent = self.short_term.get_recent(10)
        if not recent:
            return "暂无记忆"

        lines = ["=== 近期事件 ==="]
        for event in recent:
            lines.append(f"- [{event.type}] {event.data}")
        return "\n".join(lines)