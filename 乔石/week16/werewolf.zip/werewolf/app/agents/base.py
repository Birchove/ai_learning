from typing import Optional

from app.agents.memory import AgentMemory
from app.agents.strategy import RoleStrategy
from app.models import ActionType, GameState, NightAction, PrivateInfo


class RoleAgent:
    """Agent 基类"""

    def __init__(self, player_id: str, role: str, game_id: str):
        self.player_id = player_id
        self.role = role
        self.memory = AgentMemory(game_id=game_id)
        self.strategy = RoleStrategy(role)

    async def on_night_phase(
        self, game_state: GameState, private_info: PrivateInfo
    ) -> Optional[NightAction]:
        """夜间行动"""
        return None

    async def on_day_phase(self, game_state: GameState) -> str:
        """白天发言"""
        return f"我是 {self.role}，请大家合理投票。"

    async def on_vote(self, game_state: GameState) -> Optional[str]:
        """投票决策"""
        alive_players = [p for p in game_state.players if p.is_alive and p.player_id != self.player_id]
        if alive_players:
            return alive_players[0].player_id
        return None

    async def on_last_words(self) -> str:
        """遗言"""
        return f"我的身份是 {self.role}，希望大家能分辨出狼人。"

    async def receive_private_info(self, private_info: PrivateInfo) -> None:
        """接收私有信息"""
        pass

    async def think(self, game_state: GameState, context: dict) -> dict:
        """推理决策"""
        return {}

    async def update_belief(self, event: dict) -> None:
        """更新信念"""
        pass

    async def summarize_memory(self) -> str:
        """总结记忆"""
        return await self.memory.summarize_for_prompt()


class WerewolfAgent(RoleAgent):
    """狼人 Agent"""

    def __init__(self, player_id: str, game_id: str):
        super().__init__(player_id, "werewolf", game_id)

    async def on_night_phase(
        self, game_state: GameState, private_info: PrivateInfo
    ) -> Optional[NightAction]:
        """狼人夜间刀人"""
        alive_players = [p for p in game_state.players if p.is_alive and p.player_id != self.player_id]
        if alive_players:
            # 简化：选择第一个非狼人玩家
            for p in alive_players:
                if p.role != "werewolf":
                    return NightAction(
                        player_id=self.player_id,
                        action_type=ActionType.KILL,
                        target_id=p.player_id,
                    )
            return NightAction(
                player_id=self.player_id,
                action_type=ActionType.KILL,
                target_id=alive_players[0].player_id,
            )
        return None


class SeerAgent(RoleAgent):
    """预言家 Agent"""

    def __init__(self, player_id: str, game_id: str):
        super().__init__(player_id, "seer", game_id)

    async def on_night_phase(
        self, game_state: GameState, private_info: PrivateInfo
    ) -> Optional[NightAction]:
        """预言家夜间查验"""
        alive_players = [p for p in game_state.players if p.is_alive and p.player_id != self.player_id]
        if alive_players:
            return NightAction(
                player_id=self.player_id,
                action_type=ActionType.CHECK,
                target_id=alive_players[0].player_id,
            )
        return None


class WitchAgent(RoleAgent):
    """女巫 Agent"""

    def __init__(self, player_id: str, game_id: str):
        super().__init__(player_id, "witch", game_id)

    async def on_night_phase(
        self, game_state: GameState, private_info: PrivateInfo
    ) -> Optional[NightAction]:
        """女巫夜间用药（简化：不用药）"""
        return None


class HunterAgent(RoleAgent):
    """猎人 Agent"""

    def __init__(self, player_id: str, game_id: str):
        super().__init__(player_id, "hunter", game_id)

    async def on_vote(self, game_state: GameState) -> Optional[str]:
        """猎人投票"""
        return super().on_vote(game_state)


class GuardianAgent(RoleAgent):
    """守卫 Agent"""

    def __init__(self, player_id: str, game_id: str):
        super().__init__(player_id, "guardian", game_id)

    async def on_night_phase(
        self, game_state: GameState, private_info: PrivateInfo
    ) -> Optional[NightAction]:
        """守卫夜间守护"""
        candidates = [
            p for p in game_state.players
            if p.is_alive and p.player_id != private_info.guardian_cannot_protect
        ]
        if candidates:
            return NightAction(
                player_id=self.player_id,
                action_type=ActionType.PROTECT,
                target_id=candidates[0].player_id,
            )
        return None


class IdiotAgent(RoleAgent):
    """白痴 Agent"""

    def __init__(self, player_id: str, game_id: str):
        super().__init__(player_id, "idiot", game_id)


class VillagerAgent(RoleAgent):
    """平民 Agent"""

    def __init__(self, player_id: str, game_id: str):
        super().__init__(player_id, "villager", game_id)


def create_agent(player_id: str, role: str, game_id: str) -> RoleAgent:
    """工厂函数：创建对应角色的 Agent"""
    agents = {
        "werewolf": WerewolfAgent,
        "seer": SeerAgent,
        "witch": WitchAgent,
        "hunter": HunterAgent,
        "guardian": GuardianAgent,
        "idiot": IdiotAgent,
        "villager": VillagerAgent,
    }
    agent_class = agents.get(role, VillagerAgent)
    return agent_class(player_id, game_id)