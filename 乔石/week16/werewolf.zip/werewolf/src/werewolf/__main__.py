import asyncio
import sys
from pathlib import Path

# 添加项目根路径
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from app.engine.game import GameEngine


async def main():
    """游戏主入口"""
    import uuid
    print("=" * 50)
    print("AI 狼人杀 - 多智能体协作系统")
    print("=" * 50)

    game_id = str(uuid.uuid4())
    print(f"游戏ID: {game_id}")

    engine = GameEngine(game_id)
    result = await engine.start()

    print("\n" + "=" * 50)
    print(f"游戏结束")
    print(f"胜利方: {result.winner}")
    print(f"存活玩家: {[p.player_id for p in result.players if p.is_alive]}")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(main())